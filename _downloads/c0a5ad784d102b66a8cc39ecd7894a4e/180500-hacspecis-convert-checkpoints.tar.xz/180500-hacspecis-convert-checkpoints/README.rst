Reproduce
=========

- With Nix_: Run ``nix-build``
- Otherwise: Get `TeX Live`_, inkscape_, rubber_ then run ``make``.

.. _Nix: https://nixos.org/nix/
.. _TeX Live: https://www.tug.org/texlive/
.. _inkscape: https://inkscape.org/
.. _rubber: https://launchpad.net/rubber/
