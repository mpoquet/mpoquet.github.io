---
title: Introduction to the Nix Package Manager
author: Millian Poquet
theme: Estonia
date: 2021-05-27 — Workshop of the LIG Axes
lang: fr
classoption:
- aspectratio=43
header-includes:
- |
  ```{=latex}
  \usepackage{subcaption}
  \setbeamertemplate{footline}[frame number]
  \renewcommand\dots{\ifmmode\ldots\else\makebox[1em][c]{.\hfil.\hfil.}\thinspace\fi}
  \hypersetup{colorlinks,linkcolor=,urlcolor=estonian-blue}
  \graphicspath{{./fig/},{./img/}}

  % Fix pandoc shenanigans
  \setbeamertemplate{section page}{}
  \setbeamertemplate{subsection page}{}
  \AtBeginSection{}
  \AtBeginSubsection{}
  ```
---

# Introduction
### Introduction
Our use case

- Develop, test, distribute software (OAR, Melissa, Batsim...)
- Define and run controlled experiments

\vspace{5mm}
How Nix can help?

- Define/manage/customize packages and their dependencies
- Reproducible/deterministic packages
- Run code in controlled environments

### Summary

1. Nix's main concepts
2. What we do with it
3. Conclusion and additional resources

# Main concepts
### Concept 1 — How to store the packages?
\includegraphics[width=\textwidth]{pkgstruct-pacman.pdf}

Usual (non Nix) approach: Merge them all

- Default environment all the time (or hacked manually by user)
  - ``PATH`` set to ``/usr/bin`` (or similar)
  - ``LD_LIBRARY_PATH`` set to ``/usr/lib`` (or similar)
  - ``LIBRARY_PATH`` set to ``/usr/lib`` (or similar)
- Huge limitation on package variation
  - Conflicts, as present implies accessible here
  - Files do not have well-defined needs

### Concept 1 — Nix Store
\includegraphics[width=\textwidth]{pkgstruct-nix.pdf}

Nix approach: Keep them separated

- Convenient package variation
  - Different package source $\rightarrow$ Different store path
  - Files have precise dependencies \
    (``DT_RUNPATH`` in ELFs, wrappers for ``PYTHONPATH``...)
- Can *install* in default environment (tune ``PATH``...)
- Isolated environments (enter shell with well-defined ``PATH``...)

### Concept 2 — Expressions, derivations, functions

Descriptive approach

- Define packages/environments in a DSL (also called Nix)
- Derivation = build action that populates the store
- Most of the time, package = function that returns a derivation
  - Inputs: dependencies, build systems, source, build script
  - Outputs: trees of files to write in the store

\vspace{5mm}
Convenient customization

- Can ``override`` a package to change its inputs
  - Sources for a apecific version of your soft
  - Add or change a dependency
- Can also ``override`` *phases* of the build script

### Concept 3 — How to achieve reproducible builds?

Main ideas

- Package description
  - Default *phases* rarely need customization
  - Only customize what you need, do not write full build scripts
- Pure build environment (depends on arch, not system)
- Compilers told to use generic instruction sets by default
- Build in a sandbox/jail
  - No network access (*inputs* such as sources are fetched before)
  - No filesystem access (unless it is an *input*)
  - No ipc accesses (unless part of your build)
  - No time accesses: back to *epoch* we go

\vspace{3mm}
Key advantages

- Makes it really hard to change behavior depending on weather
- Do not miss dependencies anymore

# Usage examples
### What we do with Nix in a nutshell

```{=latex}
\begin{overlayarea}{\textwidth}{\textheight}
  \begin{figure}
    \centering
    \only<1>{\includegraphics[width=.8\textwidth]{whatwedo-nixexpr.pdf}}%
    \only<2>{\includegraphics[width=.8\textwidth]{whatwedo-kapack.pdf}}%
    \only<3>{\includegraphics[width=.8\textwidth]{whatwedo-expe1.pdf}}%
    \only<4>{\includegraphics[width=.8\textwidth]{whatwedo-expe2.pdf}}%
    \only<5>{\includegraphics[width=.8\textwidth]{whatwedo-batsim.pdf}}%
  \end{figure}
\end{overlayarea}
```

# Conclusion
### Take home message

Nix: Reproducible packages/environments

- Descriptive approach for packages/environments
- Multilanguage ``virtualenv`` $\rightarrow$ lightweight containers
- Steep learning curve, worth it for complex software or repro

\vspace{3mm}
Additional resources

- 1-hour introduction presentation (french)[^nix-video]
- Tutorial on Nix for reproducible experiments[^tuto-nix-repro-expe]
- Nix official website[^nix-official] — install, getting started...
- Nix pills[^nix-pills] — how Nix works

[^nix-video]: ``https://mpoquet.github.io/research.html#presentations-tutorials``
[^nix-official]: ``https://nixos.org``
[^tuto-nix-repro-expe]: ``https://nix-tutorial.gitlabpages.inria.fr/nix-tutorial``
[^nix-pills]: ``https://nixos.org/guides/nix-pills``
