Reproduce
=========

- With Nix: ``nix-build . -A slides``
- Otherwise: ``ninja`` (type ``nix-shell . -A slides`` to have all needed deps)
