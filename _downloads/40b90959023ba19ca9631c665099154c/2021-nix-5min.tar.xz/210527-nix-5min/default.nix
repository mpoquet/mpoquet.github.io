{ pkgs ? import (fetchTarball "https://github.com/NixOS/nixpkgs/archive/20.09.tar.gz") {}
}:

let
  jobs = rec {
    inherit pkgs;

    slides = pkgs.stdenv.mkDerivation {
      pname = "git-slides";
      version = "0.1.0";
      nativeBuildInputs = with pkgs; [
        texlive.combined.scheme-full
        pandoc
        ninja
        inkscape
      ];
      src = pkgs.lib.sourceByRegex ./. [
        "^build\.ninja$"
        "^fig"
        "^fig/.*\.svg"
        "^.*\.md$"
        "^.*\.sty$"
      ];
      buildPhase = ''
        ninja
      '';
      installPhase = ''
        mkdir -p $out
        mv nix.pdf $out/
      '';
    };

    autorebuild-shell = pkgs.mkShell rec {
      name = "autobuild-shell";
      buildInputs = [
        pkgs.entr pkgs.psmisc
      ] ++ slides.nativeBuildInputs;
      shellHook = ''
        ls build.ninja *.md *.sty fig/*.svg | entr -s "ninja ; killall -HUP --regexp '(.*bin/)?llpp'"
      '';
    };
  };
in
  jobs
