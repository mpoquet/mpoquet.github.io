{ kapack ? import
    (fetchTarball "https://github.com/oar-team/nur-kapack/archive/master.tar.gz") {}
}:
rec {
  pkgs = kapack.pkgs;
  expe-env = kapack.pkgs.mkShell rec {
    name = "my-experiment-env";
    buildInputs = [
      batsim-pinned
      batsched-pinned
      kapack.batexpe
    ];
  };
  batsim-pinned = (kapack.batsim.override { simgrid = kapack.simgrid-light; })
                                .overrideAttrs(old: rec {
    version = "e4e9ae56";
    src = pkgs.fetchgit {
      url = "https://gitlab.inria.fr/batsim/batsim.git";
      rev = "e4e9ae5614e04a44ac42dcb8358af35650d34453";
      sha256 = "03683cbmsr6drmacl17dqvpqnd18bh4qksmx105r79gn3bcrdsqm";
    };
  });
  batsched-pinned = kapack.batsched.overrideAttrs(old: rec {
    version = "b020e48b";
    src = pkgs.fetchgit {
      url = "https://gitlab.inria.fr/batsim/batsched.git";
      rev = "b020e48b89a675ae681eb5bcead01035405b571e";
      sha256 = "1dmx2zk25y24z3m92bsfndvvgmdg4wy2iildjmwr3drmw15s75q0";
    };
  });
}
