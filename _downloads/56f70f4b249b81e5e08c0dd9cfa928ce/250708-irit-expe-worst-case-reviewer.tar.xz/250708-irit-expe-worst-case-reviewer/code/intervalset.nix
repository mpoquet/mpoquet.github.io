{ stdenv, fetchgit, meson, ninja, pkg-config, boost, gtest }:

stdenv.mkDerivation rec {
  pname = "intervalset";
  version = "1.2.0";
  src = fetchgit {
    url = "https://framagit.org/batsim/intervalset.git";
    rev = "v${version}";
    hash = "sha256-+mG5cPgB+wAxao/8epXWrWcyvYmzmc8Un6At+6U00qs=";
  };
  buildInputs = [ meson ninja pkg-config boost gtest ];
  # configurePhase = "meson build";
  # buildPhase = "meson compile -C build";
  # checkPhase = "meson test -C build";
  # installPhase = "meson install -C build";
}
