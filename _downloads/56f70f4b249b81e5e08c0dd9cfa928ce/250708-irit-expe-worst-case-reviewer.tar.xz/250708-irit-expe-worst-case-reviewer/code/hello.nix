{ stdenv }:

stdenv.mkDerivation {
  name = "hello";
  src = ./.;
  
  phases = [ "unpackPhase" "buildPhase" "installPhase" ];
  # default unpackPhase is used
  buildPhase = ''
    gcc -o ./hello ./hello.c
  '';
  installPhase = ''
    mkdir -p $out/bin
    mv ./hello $out/bin/
  '';
}
