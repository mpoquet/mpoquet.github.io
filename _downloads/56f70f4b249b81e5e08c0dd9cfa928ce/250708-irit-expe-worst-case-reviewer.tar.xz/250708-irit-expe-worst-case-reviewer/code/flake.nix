{
  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs?ref=branch-off-24.11";
    flake-utils.url = "github:numtide/flake-utils";
  };

  outputs = { self, nixpkgs, flake-utils }:
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs { inherit system; };
      in rec {
        packages = rec {
          hello = pkgs.callPackage ./hello.nix {};
          hello-cont = pkgs.dockerTools.buildImage {
            name = "hello";
            tag = "latest";
            created = "now";
            copyToRoot = pkgs.buildEnv {
              name = "image-root";
              paths = [ hello ];
              pathsToLink = [ "/bin" ];
            };
            config.Cmd = [ "/bin/hello" ];
          };
          intervalset = pkgs.callPackage ./intervalset.nix {};
          intervalset-110 = intervalset.overrideAttrs (old: rec {
            version = "1.1.0";
            src = pkgs.fetchgit {
              url = "https://framagit.org/batsim/intervalset.git";
              rev = "v${version}";
              hash = "sha256-auMx9J8h3nqNVB4qLcnxVRua4E3jy5bNc2e/REPOek4=";
            };
          });
        };
        devShells = {
          default = pkgs.callPackage ./shell.nix {};
        };
      }
    );
}
