{ pkgs }:

pkgs.mkShell {
  buildInputs = [
    pkgs.sysbench
    
    pkgs.curl

    pkgs.python3
    pkgs.python3Packages.numpy
  ];
}
