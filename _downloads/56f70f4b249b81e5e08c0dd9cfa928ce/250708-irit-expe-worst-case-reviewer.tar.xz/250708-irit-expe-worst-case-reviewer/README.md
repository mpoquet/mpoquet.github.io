# Rebuild slides
```sh
# Enter shell where Typst is available
nix shell 'github:nixos/nixpkgs?ref=25.05#typst'

# Compile the slides
typst compile slides.typ
```
