#import "@preview/touying:0.6.1": *
#import themes.metropolis: *
#import "@preview/cetz:0.4.0"
//#import "@preview/fletcher:0.5.8" as fletcher: node, edge
//#import "@preview/codly:1.3.0": *
//#import "@preview/codly-languages:0.1.8": *
//#import "@preview/numbly:0.1.0": numbly
#import "@preview/showybox:2.0.4": showybox

//#set heading(numbering: numbly("{1}.", default: "1.1"))
#set par(justify: true)
#show link: v => underline(text(v, font: "DejaVu Sans Mono", weight: "regular", size: .8em, fill: blue))
#set raw(theme: "mpoquet.tmTheme")
//#show: codly-init.with()
//#codly(display-name: false)

#let metrocolor = rgb("#23373b")
#let def-box = showybox.with(frame: (title-color: metrocolor), title-style: (color: white, align: left))

// cetz and fletcher bindings for touying
#let cetz-canvas = touying-reducer.with(reduce: cetz.canvas, cover: cetz.draw.hide.with(bounds: true))
//#let fletcher-diagram = touying-reducer.with(reduce: fletcher.diagram, cover: fletcher.hide)

#show: metropolis-theme.with(
  aspect-ratio: "16-9",
  config-info(
    title: [Experimenting for the Worst-Case Reviewer],
    subtitle: [Tools and Tips for REP Hygiene\ IRIT PhD days -- ASR department],
    author: [Millian #smallcaps[Poquet]],
    date: [2025-07-08],
  ),
)

#let terminal(width: 100%, height: auto,
  fill: rgb("#282c34"), stroke: none,
  text-color: rgb("#ffffff"),
  pad-x: 2mm, pad-y: 2mm,
  content
) = {
  block(width: width, height: height, fill: fill, stroke: stroke, {
    show: pad.with(x: pad-x, y: pad-y)
    show raw: set text(fill: text-color)
    show regex("\$"): set text(fill: rgb("#f9de2d"))
    show regex("\(nix-shell\)"): set text(fill: rgb("#c678dd"))
    content
  })
}

#show strong: it => text(fill: luma(10%), it)

#title-slide()

== Who am I?
#slide[
  Millian #smallcaps[Poquet]
  - MCF Univ. Toulouse / IRIT
  - `millian.poquet@irit.fr`
  - https://mpoquet.github.io $<-$ slides available

  Research interests
  - Resource management on distributed systems
  - Energy & performance optimization
  - Sustainability
  - How to experiment on these systems (simulation, real)

  Propaganda / bias warning
  - Long-term Nix user, NixOS maintainer
  - Long-term Grid'5000 user, IRIT group co-manager
]

= Introduction
== Stories
#slide[
  *Story 1* -- Bob is writing its manuscript\
  When redoing graphs for manuscript, he finds out results have completely changed `:(`

  #v(1cm)
  *Story 2* -- Bob left, Alice wants to continue his work\
  Cannot find/run/modify existing work without great effort `:(`
]

== This talk in a nutshell
#slide[
  Have you read this paper?\
  - _Want People to Read Your Paper? Consider the Worst-Case Reviewer_#footnote[https://www.sigarch.org/want-people-to-read-your-paper-consider-the-worst-case-reviewer/]

  #pause
  This talk focuses on making your experiments robust to the Worst-Case Reviewer -- that's me

  #v(1cm)
  *Side effects*
  - Increased likelihood of papers accepted
  - Increased likelihood of work being reused
  - Increased likelihood of gaining insights?
]

== Outline
#slide[
  #let outline-gray = luma(70%)
  #set outline.entry(fill: line(length: 100%, stroke: outline-gray))
  #let secnames-skip = ("Nix", "Artifact", "Conclusion")
  #show outline.entry: it => {
    let secname = it.inner().at("children").at(0).at("text", default: "no")
    if secnames-skip.contains(secname) {
      v(5mm)
    }
    let fill-color = rgb("#23373b")
    if secname == "Introduction" {
      fill-color = outline-gray
    }
    it.indented(it.prefix(), text(fill: fill-color, it.body()))
  }
  #pad(left: 5cm, right: 10cm, outline(title: none, depth: 1))
]

= REP & what can go wrong
== REP definitions
#slide[
  ACM terminology#footnote[https://www.acm.org/publications/policies/artifact-review-and-badging-current] as of 2020-08-24
  - *REPeatability* (same team, same experimental setup)\
  - *REProducibility* (different team, same experimental setup)
  - *REPlicability* (different team, different experimental setup)

  #def-box(title: [Reproducibility definition])[_The *measurement* can be obtained with *stated precision* by a *different team* using the *same measurement procedure*, the *same measuring system*, under the *same operating conditions*, in the *same or a different location* on multiple trials. For computational experiments, this means that an *independent group* can obtain the same result using the *author's own artifacts*._]
]

== My opinion of these definitions
#slide[
  *Positives*
  - Attempt to standardize terminology
  - Same/different team encompasses many problems --- lack of code, lack of doc...

  #v(1cm)
  *Negatives*
  - Very vague. What kind of measurement? What kind of measurement procedure?
  - Statistical REP? Binary REP?
  - REP with mutability?
  - Longevity of REP?
]

== What can go wrong? vague software (algo ≠ implem)
#slide[
  It is common to see simple subtaks not detailed in algorithms in papers --- _e.g._, `tolower(s)`\
  - But how they are implemented can change the results of your experimental setup `:/`

  #pause
  #set text(size: .8em)
  ```c
  void tolower_simple_libc(const char *input, char *output, size_t size) {
    unsigned int usize = (unsigned int)size;
    for (unsigned int i = 0; i < usize; i++) {
      output[i] = tolower((unsigned char)input[i]);
    }
  }
  ```
  #pause
  ```c
  void tolower_simple_diy(const char *input, char *output, size_t size) {
    unsigned int usize = (unsigned int)size;
    for (unsigned int i = 0; i < usize; i++) {
        char c = input[i];
        if (c >= 'A' && c <= 'Z') {
            output[i] = c + 32;
        } else {
            output[i] = c;
        }
    }
  }

  ```
]

== What can go wrong? vague software (algo ≠ implem)
#slide[
  #set text(size: .8em)
  ```c
  void tolower_vec(const char *input, char *output, size_t size) {
    const __m256i a_minus1 = _mm256_set1_epi8('A' - 1);
    const __m256i z_plus1 = _mm256_set1_epi8('Z' + 1);
    const __m256i delta = _mm256_set1_epi8(32);
    unsigned int usize = (unsigned int)size;
    unsigned int vec_chunks = usize / 32;

    for (unsigned int i = 0; i < vec_chunks; i++) {
        unsigned int offset = i * 32;
        __m256i data = _mm256_loadu_si256((const __m256i*)(input + offset));
        __m256i mask_upper = _mm256_and_si256(
            _mm256_cmpgt_epi8(data, a_minus1),
            _mm256_cmpgt_epi8(z_plus1, data)
        );
        __m256i result = _mm256_or_si256(
            _mm256_and_si256(mask_upper, _mm256_add_epi8(data, delta)),
            _mm256_andnot_si256(mask_upper, data)
        );
        _mm256_storeu_si256((__m256i*)(output + offset), result);
    }
  }
  ```
]

== What can go wrong? vague software (algo ≠ implem) --- performance
#slide[
  #set align(center+horizon)
  #image(width: 100%, "./fig/expe-comp/gcc14-O2.svg")
]

== What can go wrong? compilation options
#slide[
  #set align(center+horizon)
  #image(width: 100%, "./fig/expe-comp/gcc14.svg")
]

== What can go wrong? compilation environment (option=`-O2`)
#slide[
  #set align(center+horizon)
  #image(width: 100%, "./fig/expe-comp/O2.svg")
]

== What can go wrong? "homogeneous" machines -- `dahu` cluster, `vec`, `gcc14`, `-O2`
#slide[
  #set align(center+horizon)
  #image(width: 100%, "./fig/expe-multinode/vec.svg")
]

== What can go wrong? "homogeneous" machines
#slide[
  TODO `:(`

  Previous microbenchmark only uses memory and CPU
  - CPU have usually similar performance in the same cluster
  - That's not the case of other components -- _e.g._, disks
]

== What can go wrong? different machines
#slide[
  TODO `:(`

  #align(center, image("./fig/geo-median-power-npb-g5k.png", width: 80%))

  _Da Costa, G. Power, performance and system measures of HPC benchmarks on multiple hardware_\
  https://doi.org/10.5281/zenodo.10982239
]

== What can go wrong? filesystem
#slide[
  TODO `:(`

  #v(5mm)
  Preliminary run (no repetition) with commands such as this one:
  ```bash
    fio --randrepeat=1 --ioengine=libaio --direct=0 --gtod_reduce=1 \
        --name=test --numjobs=32 --bs=4k --iodepth=64 --readwrite=randrw \
        --rwmixread=75 --size=256M --filename=/tmp/tmpfs/testfile
  ```

  #v(5mm)
  Gave results such as these ones:
  #show table.cell: it => {
    if it.y == 0 {
      strong(delta: 250, it)
    } else {
      it
    }
  }
  #table(
    columns: 4,
    table.header(
      [storage],
      [fs],
      [read bw (MiB/s)],
      [write bw (MiB/s)],
    ),
    align: right,
    [local ssd], [`tmpfs`], [4759], [1586],
    [local ssd], [`ext4`], [2741], [914],
    [local ssd], [`overlayfs`], [1676], [559],
    [remote `?`], [`nfs`], [490], [164],
  )

  // tmpfs
  //   Run status group 0 (all jobs):
  //     READ: bw=4759MiB/s (4990MB/s), 149MiB/s-152MiB/s (156MB/s-159MB/s), io=96.0GiB (103GB), run=20262-20656msec
  //     WRITE: bw=1586MiB/s (1663MB/s), 49.5MiB/s-50.5MiB/s (51.9MB/s-52.9MB/s), io=31.0GiB (34.4GB), run=20262-20656msec

  // local disk, ext4
  //   Run status group 0 (all jobs):
  //     READ: bw=2741MiB/s (2874MB/s), 85.5MiB/s-86.1MiB/s (89.7MB/s-90.3MB/s), io=96.0GiB (103GB), run=35721-35869msec
  //     WRITE: bw=914MiB/s (958MB/s), 28.5MiB/s-28.7MiB/s (29.9MB/s-30.1MB/s), io=31.0GiB (34.4GB), run=35721-35869msec
  //   Disk stats (read/write):
  //     sda: ios=786940/145062, merge=0/308, ticks=246478/154847, in_queue=401325, util=75.01%

  // local disk, overlayfs (1G because too long)
  //   Run status group 0 (all jobs):
  //     READ: bw=1676MiB/s (1757MB/s), 52.3MiB/s-52.9MiB/s (54.8MB/s-55.5MB/s), io=23.0GiB (25.8GB), run=14538-14666msec
  //     WRITE: bw=559MiB/s (586MB/s), 17.4MiB/s-17.6MiB/s (18.2MB/s-18.5MB/s), io=8195MiB (8593MB), run=14538-14666msec

  // nfs (256M because too long)
  //   Run status group 0 (all jobs):
  //     READ: bw=490MiB/s (514MB/s), 15.3MiB/s-16.7MiB/s (16.1MB/s-17.6MB/s), io=6143MiB (6441MB), run=11491-12524msec
  //     WRITE: bw=164MiB/s (172MB/s), 5192KiB/s-5667KiB/s (5316kB/s-5803kB/s), io=2049MiB (2149MB), run=11491-12524msec
]

== What can go wrong? version of #underline[your] software
#slide[
  TODO `:(`

  Example: 1 Batsim commit divided execution time by 2 --- remove `printf` in critical path
]

== What can go wrong? version of #underline[some] software (dep)
#slide[
  TODO `:(`

  Example: external Batsim users used Batsim with SimGrid compiled without any optimization
  Problem: SimGrid has a *HUGE* impact on performance
  - SimGrid does user-space scheduling
  - SimGrid solves hard resource sharing problem for each simulation time step

  Execution time of 1 simulation, big picture:
  - on my PhD laptop, with optimizations: `< 1 s`\
  - on external user's machine, without optimization: timeout after several minutes
]

== What can go wrong? CPU freq changed
#slide[
  TODO `:(`

  #image("./fig/geo-median-power-npb-g5k.png", width: 80%)

  _Da Costa, G. Power, performance and system measures of HPC benchmarks on multiple hardware_\
  https://doi.org/10.5281/zenodo.10982239_
]

== What can go wrong? kernel
#slide[
  TODO `:(`

  Idea
  - Kernel versions can have impact on (functional) results
  - Some kernel options have strong impact on performance (mitigations, scheduling...)
]

== What can go wrong? external resource has changed/disappeared 🙀
#slide[
  *Data service*
  - Input data lost

  *Source forge*
  - Google code
  - Inria's gforge
  - When will GitHub disappear?

  *Hardware*
  - `:(`
]

== What can go wrong? Summary
#slide[
  *Impact?*
  - Can no longer run anything
  - Can run but main outputs differ (binary or statistical diff)
  - Can run but non-functional metrics differ (performance, power...)
  *Why?*
  - Unreliable external sources (random service, closed-source stuff...)
  - Uncontrolled software
    - Your software
    - Your dependencies
    - OS and various _hidden_ services
  - Uncontrolled hardware
    - State: voltage/frequency, temperature...
    - (Real) network connections...
]

== What can go wrong? many more things!
#slide[

]

== Expe & control
#slide[
  Slide from SMPE#footnote[https://github.com/alegrand/SMPE]'s lecture on Design of Experiments

  #grid(
    columns: (50%, 44%),
    column-gutter: 1cm,
    [
      *Blackbox model* for the system under study
      - All inputs may not be known
        - Some can be controlled
        - Some cannot
      - All outputs may not be known
    ],
    image("./fig/control-factors.svg", width: 100%)
  )

  *Main idea*
  - Define the set of relevant response
  - Determine the set of relevant factors/variables
]

== What should be controlled? How?
#slide[
  IMO, *as much as is reasonably possible* and is useful for your experiment
  - Your software : your code + all your user-space dependencies
  - Your software execution environment: how your software is run
  - OS config & version
  - Hardware setup

  Even if you don't control it, try to *carefully record* factors you think relevant\
  In particular, *timestamps* allow to check many things a posteriori

  Enabling control with *mutability* is critical in computer science IMO
  - Performance strongly depends on hardware/software environments, that evolve

  #v(5mm)
  #pause
  The next sections of this talk give examples on how to control
  - Your user-space software via *Nix*
  - Some OS config/version & hardware setup via *Grid'5000*
]

= Nix
== Nix's main idea
#slide[
  #def-box(title: [Definition])[
    An operation is said to have a *side effect* if it has any observable effect other than its primary effect of reading the value of its arguments and returning a value to the invoker of the operation.
  ]

  #v(1cm)
  #pause
  How to manage software *without* side effects ?
  - *Immutable* file system to store packages
  - *Pure* functions to build packages
  - *Cryptographic hashes* for external data (source code...)
]

== What is Nix?
#slide[
  #grid(
    columns: (auto, 7cm),
    column-gutter: 4cm,
    [
      *Nix*: package manager
      - Download, store and _install_ packages
      - Get into tmp well-defined environments (shells)\
        - `virtualenv`, but for any language\
        - `docker run`, but without isolation

      *Nix*: programming language
      - #sym.lambda DSL
      - Define how to build packages
      - Define environments (set of packages)

      *NixOS*: Linux distribution
      - Declarative system config via Nix language
      - Sources: https://github.com/NixOS/nixpkgs
    ],
    image("fig/nix-logo.svg", width: auto),
  )
]

== How to store packages?
#slide[
  #grid(
    columns: (1fr, 8cm),
    column-gutter: 2cm,
    [
      *Filesystem Hierarchy Standard*
      - All packages merged together
      - Multiversion is tedious
      - Always in the _default_ environment
        - ELFs with vague deps -- `require libmylib.so`
        - Libs from default paths (`/lib`, `/usr/lib`, or `ldconfig`)
        - PATH to default paths or hacked
    ],
    [
      #set align(right)
      #cetz-canvas({
        import cetz.draw: *
        let x = 1.1
        let xo = 0.2
        let y = -0.8
        let yo = 0.2
        content((0,0), anchor: "text", `/usr`)
        content((1*x,1*y), anchor: "text", `bin`)
        content((2*x,2*y), anchor: "text", `program`)
        content((1*x,3*y), anchor: "text", `lib`)
        content((2*x,4*y), anchor: "text", `libc.so`)
        content((2*x,5*y), anchor: "text", `libmylib.so`)

        line((xo,-yo), (xo,3*y + yo), (1*x - xo, 3*y + yo))
        line((xo,-yo), (xo,1*y + yo), (1*x - xo, 1*y + yo))
        line((1*x + xo, 1*y - yo), (1*x + xo, 2*y + yo), (2*x - xo, 2*y + yo))
        line((1*x + xo, 3*y - yo), (1*x + xo, 4*y + yo), (2*x - xo, 4*y + yo))
        line((1*x + xo, 3*y - yo), (1*x + xo, 5*y + yo), (2*x - xo, 5*y + yo))
      })
    ]
  )
]

== How to store packages?
#slide[
  *Nix Store*
  - Each package in its own directory + links
  - Naming: hash of inputs + package name + package "version"
  - Precise dependencies
    - ELFs have set `DT_RUNPATH`
    - Wrapper scripts to set `PATH`, `PYTHONPATH`...
  #v(6mm)
  #cetz-canvas({
    import cetz.draw: *
    let x = 1.1
    let xo = 0.2
    let y = -0.8
    let yo = 0.2
    content((0,0), anchor: "text", `/nix/store`)
    content((1*x,1*y), anchor: "text", `y9zg6ryffgc5c9y67fcmfdkyyiivjzpj-glibc-2.27`)
    content((2*x,2*y), anchor: "text", `lib`)
    content((3*x,3*y), anchor: "text", `libc.so`)
    content((1*x,4*y), anchor: "text", `nc5qbagm3wqfg2lv1gwj3r3bn88dpqr8-mypkg-0.1.0`)
    content((2*x,5*y), anchor: "text", `bin`)
    content((3*x,6*y), anchor: "text", `program`)
    content((2*x,7*y), anchor: "text", `lib`)
    content((3*x,8*y), anchor: "text", `libmylib.so`)

    line((xo,-yo), (xo,1*y + yo), (1*x - xo, 1*y + yo))
    line((xo,-yo), (xo,4*y + yo), (1*x - xo, 4*y + yo))
    line((1*x + xo, 1*y - yo), (1*x + xo, 2*y + yo), (2*x - xo, 2*y + yo))
    line((1*x + xo, 4*y - yo), (1*x + xo, 5*y + yo), (2*x - xo, 5*y + yo))
    line((1*x + xo, 4*y - yo), (1*x + xo, 7*y + yo), (2*x - xo, 7*y + yo))
    line((2*x + xo, 2*y - yo), (2*x + xo, 3*y + yo), (3*x - xo, 3*y + yo))
    line((2*x + xo, 5*y - yo), (2*x + xo, 6*y + yo), (3*x - xo, 6*y + yo))
    line((2*x + xo, 7*y - yo), (2*x + xo, 8*y + yo), (3*x - xo, 8*y + yo))

    set-style(mark: (end: ">", fill: black, scale: 2), stroke: black)
    bezier((6, 6*y + yo), (6, 3*y + yo), (30, 3*y))
    bezier((6, 6*y + yo - 0.1), (7.25, 8*y + yo), (15, 7*y))
  })
]

== How does Nix achieve purity?
#slide[
  *Main ideas*
  - Content hash used for external data (source code / bootstrap)
  - Packages are built in a sandbox (Linux namespaces)
    - Controlled builder args and env vars
    - No filesystem access outside of build script / sources / deps
    - No network/ipc/... access

  #grid(
    columns: (auto, 1fr),
    column-gutter: 2cm,
    [
      *Workflow to build a package*
      + Build all deps
      + Run build in sandbox
        - Input: build script (read-only)
        - Inputs: all deps paths (read-only)
        - Outputs: temp dirs
      + temp dirs $->$ Store (DB transaction)
    ],
    [
      #v(-5mm)
      #cetz-canvas({
        import cetz.draw: *
        let xbo = 0
        let x = 1.1
        let xo = 0.2
        let y = -0.8
        let yo = 0.2

        rect((-0.25,0.5), (6, -5.25), fill: luma(90%))
        content(((-0.25 + 6) / 2, -6.5), align(center)[Filesystem view\ from sandbox])

        content((xbo+0,0), anchor: "text", `/`)
        content((xbo+1*x,1*y), anchor: "text", `nix/store`)
        content((xbo+2*x,2*y), anchor: "text", `[a]-gcc`)
        content((xbo+2*x,3*y), anchor: "text", `[b]-mydep1`)
        content((xbo+2*x,4*y), anchor: "text", `[c]-mydep2`)
        content((xbo+1*x,5*y), anchor: "text", `build`)
        content((xbo+1*x,6*y), anchor: "text", `out`)

        line(                (xbo + xo,1*y + yo), (xbo + 1*x - xo, 1*y + yo))
        line(                (xbo + xo,5*y + yo), (xbo + 1*x - xo, 5*y + yo))
        line((xbo + xo,-yo), (xbo + xo,6*y + yo), (xbo + 1*x - xo, 6*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 2*y + yo), (xbo + 2*x - xo, 2*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 3*y + yo), (xbo + 2*x - xo, 3*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 4*y + yo), (xbo + 2*x - xo, 4*y + yo))

        xbo = 8
        content((xbo+0,0), anchor: "text", `/`)
        content((xbo+1*x,1*y), anchor: "text", `nix/store`)
        content((xbo+2*x,2*y), anchor: "text", `[a]-gcc`)
        content((xbo+2*x,3*y), anchor: "text", `[b]-mydep1`)
        content((xbo+2*x,4*y), anchor: "text", `[c]-mydep2`)
        content((xbo+2*x,5*y), anchor: "text", `...`)
        content((xbo+1*x,6*y), anchor: "text", `...`)
        content((xbo+1*x,7*y), anchor: "text", `tmp`)
        content((xbo+2*x,8*y), anchor: "text", `tmp.01`)
        content((xbo+2*x,9*y), anchor: "text", `tmp.02`)

        line(                (xbo + xo,1*y + yo), (xbo + 1*x - xo, 1*y + yo))
        line(                (xbo + xo,6*y + yo), (xbo + 1*x - xo, 6*y + yo))
        line((xbo + xo,-yo), (xbo + xo,7*y + yo), (xbo + 1*x - xo, 7*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 2*y + yo), (xbo + 2*x - xo, 2*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 3*y + yo), (xbo + 2*x - xo, 3*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 4*y + yo), (xbo + 2*x - xo, 4*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 5*y + yo), (xbo + 2*x - xo, 5*y + yo))
        line((xbo + 1*x + xo, 7*y - yo), (xbo + 1*x + xo, 8*y + yo), (xbo + 2*x - xo, 8*y + yo))
        line((xbo + 1*x + xo, 7*y - yo), (xbo + 1*x + xo, 9*y + yo), (xbo + 2*x - xo, 9*y + yo))

        set-style(mark: (end: ">", fill: metrocolor, scale: 2.5), stroke: (paint: black))
        line((5, 2*y + yo), (9, 2*y + yo))
        line((5.75, 3*y + yo), (9, 3*y + yo))
        line((5.75, 4*y + yo), (9, 4*y + yo))
        line((3, 5*y + yo), (7.75, 5*y + yo), (7.75, 8*y + yo), (9, 8*y + yo))
        line((2.25, 6*y + yo), (6.5, 6*y + yo), (6.5, 9*y + yo), (9, 9*y + yo))
      })
    ],
  )
]

== How does Nix achieve purity? derivation tree
#slide[
  TODO `:(`

  Idea: Tree of #sym.lambda calls
  - Leaves: content-hashed external data (sources, bootstrap compilers)
  - Intermediate nodes: compilers, your indirect dependencies, your direct dependencies
  - Root: your package
]

== Nix #sym.lambda example -- explicit hello world package
#slide[
  #grid(
    columns: (60%, 25%),
    column-gutter: 2.5cm,
    align: top,
    [
      #set text(size: .8em)
      #showybox(frame: (inset: (x: 0.25em, y: 0.5em)))[
        #let hello-nix-fn = read("./code/hello.nix")
        #raw(hello-nix-fn, lang: "nix")
      ]
    ],
    [
      Entry points
      + `prePhases`
      + `unpackPhase`
      + `patchPhase`
      + `(pre)configurePhase`
      + `(pre)buildPhase`
      + `checkPhase`
      + `(pre)installPhase`
      + ...
      + `postPhases`

      #v(5mm)
      Customized by
      - setting `phases`
      - using another builder
    ],
  )
]

== Nix #sym.lambda example -- real package, using a build system
#slide[
  #grid(
    columns: (1fr, 33%),
    column-gutter: 1cm,
    [
      #set text(size: .75em)
      #showybox(width: 100%, frame: (inset: (x: 0.5em, y: 0.5em)))[
        #let hello-nix-fn = read("./code/intervalset.nix")
        #raw(hello-nix-fn, lang: "nix")
      ]
    ],
    [
      Usual build layers
      - Package manager: `nix`, `apt`...
      - Build system: `meson`, `cmake`...
      - DAG builder: `ninja`, `make`...
      - Compiler: `clang`, `gcc`...
    ],
  )
]

== Package customization -- tune #sym.lambda args via `override`
#slide[
  #set text(size: .8em)
  #showybox(width:75%)[
    ```nix
    packages = rec {
      intervalset = pkgs.callPackage ./intervalset.nix { };
      intervalset-as-debian10 = intervalset.override {
        boost = boost-167;
        meson = meson-049;
      };

      boost-176 = ...;
      boost-167 = ...;
      boost = boost-176;

      meson-058 = ...;
      meson-049 = ...;
      meson = meson-058;
    };
    ```
  ]
]

== Package customization -- tune #sym.lambda definition via `overrideAttrs`
#slide[
  #set text(size: .8em)
  #showybox(width:75%)[
    ```nix
    packages = rec {
      intervalset = pkgs.callPackage ./intervalset.nix { };
      intervalset-110 = intervalset.overrideAttrs (old: rec {
        version = "1.1.0";
        src = pkgs.fetchgit {
          url = "https://framagit.org/batsim/intervalset.git";
          rev = "v${version}";
          hash = "sha256-auMx9J8h3nqNVB4qLcnxVRua4E3jy5bNc2e/REPOek4=";
        };
      });
      intervalset-local = intervalset.overrideAttrs (old: rec {
        version = "local";
        src = "/home/user/projects/intervalset";
        mesonBuildType = "debug";
      });
    };
    ```
  ]
]

== Nix code example -- shell
#slide[
  #set text(size: .75em)
  #grid(
    columns: (30%, 1fr),
    column-gutter: 5mm,
    align: top,
    [
      #showybox(frame: (inset: (x: 0.25em, y: 0.5em)))[
        #let hello-nix-fn = read("./code/shell.nix")
        #raw(hello-nix-fn, lang: "nix")
      ]
    ],
    [
      #terminal[
        ```
        $ sysbench --version
        sh: sysbench: command not found
        $ python --version
        sh: python: command not found

        $ nix-shell ...
        (nix-shell) $ sysbench --version
        sysbench 1.0.20
        (nix-shell) $ python --version
        Python 3.12.7
        (nix-shell) $ python
        Python 3.12.7 (main, Oct  1 2024, 02:05:46) [GCC 13.3.0] on linux
        Type "help", "copyright", "credits" or "license" for more information.
        >>> import numpy
        >>> numpy.__version__
        '1.26.4'
        >>> exit()
        ```
      ]
    ]
  )
]

== Nix code example -- container
#slide[
  #set text(size: .75em)
  #grid(
    columns: (46%, 50%),
    column-gutter: 1fr,
    align: top,
    def-box(title: text(size: 1.33em)[Big image])[
      ```nix
      packages = rec {
        hello = pkgs.callPackage ./hello.nix {};
        hello-cont = pkgs.dockerTools.buildImage {
          name = "hello";
          tag = "latest";
          created = "now";
          copyToRoot = pkgs.buildEnv {
            name = "image-root";
            paths = [ hello ];
            pathsToLink = [ "/bin" ];
          };
          config.Cmd = [ "/bin/hello" ];
        };
      };
      ```
    ],
    def-box(title: text(size: 1.33em)[2 layers])[
      ```nix
      { dockerTools, batsim, bash }:
      let self = rec {
        layer-dependencies = dockerTools.buildImage {
          name = "oarteam/batsim-deps";
          tag = batsim.version;
          copyToRoot = batsim.runtimeDeps ++ [ bash ];
        };
        layer-batsim = dockerTools.buildImage {
          fromImage = layer-dependencies;
          fromImageName = layer-dependencies.name;
          fromImageTag = layer-dependencies.tag;
          tag = layer-dependencies.tag;
          name = "oarteam/batsim";
          config = {
            # ...
          };
        };
      };
      in
        self.layer-batsim
      ```
    ],
  )
]

== Where to write your Nix expressions?
#slide[
  Evaluating remote (git, some https server...) Nix expressions is as easy as local ones (files)\
  $->$ You are free to decide where to write your Nix files

  #v(1cm)
  *Common locations*
  - Git repo of your software
  - Git repo of your experiment
  - Git repo of a set of tools you (or your team/lab/...) manage
  - Nixpkgs
]

== Nix $->$ control software env. Limits?
#slide[
  Reproducible builds only if
  - Compiler is deterministic
  - Build chain (build system...) is deterministic

  #v(-5mm)
  #def-box(title: [Quote from the Meson's doc])[
    _
    Meson aims to support reproducible builds out of the box with zero additional work (assuming the rest of the build environment is set up for reproducibility). If you ever find a case where this is not happening, it is a bug. Please file an issue with as much information as possible and we'll get it fixed.
    _
  ]

  Contaminant approach -- cannot reuse non-Nix packages
  - Nixpkgs has much more packages than any other Linux distro#footnote[https://repology.org/repositories/statistics #linebreak() #h(8mm) As of 2025-06-23, nixpkgs=106475, AUR=78079, debian12=34451]
  - Writing a Nix package is straightforward most of the time
]

= Grid'5000
== Grid'5000 overview
#slide[
  #grid(
    columns: (60%, 40%),
    [
      *Testbed* for computer science research
      - large scale
      - flexible
      - experiment-driven

      *Key features*
      - 800 nodes, 15000 cores
      - highly reconfigurable & controllable
      - advanced monitoring / measurements
      - strongly relies on OSS
    ],
    image("./fig/g5k-backbone.svg", )
  )
]

== Hardware heterogeneity
#slide[
  *Some clusters*
  - `dahu` : 32 nodes -- 2x Intel Xeon Gold 6130, 192 GiB, 240 GB SSD, Omni-Path
  - `drac` : 12 nodes -- 2x IBM POWER8NVL 1.0, ..., InfiniBand, 4x Nvidia Tesla P100
  - `estats` : 12 nodes -- 1x Nvidia Carmel (`aarch64`), 1x Nvidia AGX Xavier
  - `sirius` : 1 node -- 2x AMD EPYC 7742, 1.92 TB SSD, 8x Nvidia A100
  - `servan` : 2 nodes -- 2x AMD EPYC 7352, ..., 2x 100 Gbps FPGA
  - `engelbourg` : 8 nodes -- 1x Intel Pentium D1517, ..., P4 switch
]

== Environment control
#slide[
  Operating system
  - Debian (updated regularly) on most clusters
  - Specific OS on some clusters -- _e.g._, Nvidia-customized Ubuntu on `estats`
  - *What you want* with `kadeploy`

  Build your own system image
  - With `kameleon` -- imperative approach
  - With `NixOS (Compose)` -- functional approach
  - How you want as long as you provide `kadeploy`-compatible files

  Network
  - VLAN with `kavlan`
  - Real topology is hard to change, but emulation#footnote[https://www.grid5000.fr/w/Network_emulation] via `netem`/`distem`/`enoslib`
]

== How useful is Grid'5000 to your research?
#slide[
  I cannot tell, I don't know what you work on `:/`

  Most likely useful if you
  - Work on distributed systems (lots of different configurable nodes)
  - Work on operating systems (clean automatic bare-metal deployments)
  - Need computing resources to run programs -- _e.g._, simulation campaigns
  - Work on performance/power evaluation, if your hw/network needs are not too specific
]

== Accessing Grid'5000
#slide[
  #grid(
    columns: (60%, 40%),
    column-gutter: 1fr,
    align: top,
    [
      *Getting Access*
      + Create your account#footnote[https://www.grid5000.fr/w/Grid5000:Get_an_account]
      + Accept the usage policy#footnote[https://www.grid5000.fr/w/Grid5000:UsagePolicy]
      + Follow the Getting Started tutorial#footnote[https://www.grid5000.fr/w/Getting_Started]
      + Follow other tutorials#footnote[https://www.grid5000.fr/w/Users_Home]
      + Communicate with users or admins#footnote[https://www.grid5000.fr/w/Support]
    ],
    [
      *Technically*
      + `ssh` on a frontend
      + reserve resources with OAR
      + use resources interactively or not
    ],
  )
]

= Artifact
== Artifact?
#slide[
  #def-box(title: [From USENIX OSDI'25 Call for Artifacts#footnote[https://www.usenix.org/conference/osdi25/call-for-artifacts]])[
    _A scientific paper consists of a constellation of artifacts that extend beyond the document itself: software, hardware, evaluation data and documentation, raw survey results, mechanized proofs, models, test suites, benchmarks, and so on. *In some cases, the quality of these artifacts is as important as that of the document itself*._
  ]

  Forgotten before, encouraged now, *forced soon?*
  - SC since 2016: description *mandatory*, evaluation optional
  - ACM REP since 2023: AD+AE *mandatory* for full papers with experimental results
  - USENIX OSDI'24: 69% of accepted papers participated in the artifact evaluation process
]

== How to do an artifact?
#slide[
  *Use cases*
  - Reviewer/Reader wants to check result analysis, using existing data
  - Reviewer/Reader wants to check a result, running a subpart of the experiment
  - Researcher wants to reuse parts of the experiment setup

  #pause
  *How to document* your experiment?
  - Big README with shell blocks?
  - Bunch of scripts?
  - Automate everything with some workflow system?

  #pause
  The best way to it depends on your experiment, *but*
  - Enable reusing parts of the experiments (sofware engineering)
    - Can be tricky -- _e.g.,_ custom OS deployment without being Grid'5000 specific
  - Provide a high-level documentation
  - Enable exploration: Keep things as stupid as possible
  - Enable variation: Show how to tune important parameters, software environment...
]

== Artifact example : toy "experiments" for this talk
#slide[
  https://gitlab.irit.fr/sepia-pub/open-science/non-rep-src-irit-phd-days
]

== Artifact example : one we did for Euro-Par'24
#slide[
  Code of experimental setup in Git repo, duplicated for longevity
  - Public repo #link("https://gitlab.irit.fr/sepia-pub/open-science/artifact-europar24-lightweight-power-pred-sched")[at irit]
  - Public repo #link("https://framagit.org/batsim/artifact-europar24-lightweight-power-pred-sched")[at framagit]
  - Long-term archive #link("https://archive.softwareheritage.org/swh:1:rev:5a15139dadde8d923703ece93745fa250b1a0c53;origin=https://framagit.org/batsim/artifact-europar24-lightweight-power-pred-sched.git;visit=swh:1:snp:968650e57128ea88b02a858279a7054f62f0a0b0")[on Software Heritage]

  Various needed software in their own repos
  - All their source codes & Nix descriptions archived on Software Heritage

  Measurements & analysis notebooks (more details than what fit in paper)
  - #link("https://zenodo.org/records/11208389")[On Zenodo]
]

= Methods
== REP hygiene VS patching holes and cracks
#slide[
  Current *REP* crisis is mostly a *methodological* crisis

  REP is too often an afterthought of your experiment
  - How to trace your scientific decisions?
  - How to enable people joining the work along the way easily?

  IMO sane REP practice should be used early on in your experiment
  - Very similar to software engineering good practices
]

== A fool with a tool...
#slide[
  *is still a fool!*\
  Tools such as Nix and Grid'5000 help, but *method* is the key to achieve REP

  IMO Computer science is immature and lacks standardized protocols *but*
  - You need to learn about most common _bad research_ practices#footnote[https://www.polytechnique-insights.com/en/braincamps/society/what-does-it-mean-to-trust-science/science-can-suffer-from-lack-of-reproducibility-of-results/]
    - Data dredging ($p$-hacking): Perform many statistical tests on the data and only report those that come back with significant results
    - HARKing: Hypothesizing after the results are known
    - Publication bias towards _positive_ results
    - ...
  - You need to plan your experiments
    - Exploration #sym.eq.not Testing your hypotheses
    - Consider €/environmental costs
]

== Ten Simple Rules for Reproducible Computational Research --- comp. biology
#slide[
  From Sandve GK, Nekrutenko A, Taylor J, Hovig E (2013)#footnote[https://doi.org/10.1371/journal.pcbi.1003285]
  + For Every Result, Keep Track of How It Was Produced
  + Avoid Manual Data Manipulation Steps
  + Archive the Exact Versions of All External Programs Used
  + Version Control All Custom Scripts
  + Record All Intermediate Results, When Possible in Standardized Formats
  + For Analyses That Include Randomness, Note Underlying Random Seeds
  + Always Store Raw Data behind Plots
  + Generate Hierarchical Analysis Output,\
    Allowing Layers of Increasing Detail to Be Inspected
  + Connect Textual Statements to Underlying Results
  + Provide Public Access to Scripts, Runs, and Results
]

== Best Practices for Scientific Computing --- bioinformatics
#slide[
  From Wilson G, Aruliah DA, Brown CT, Chue Hong NP, Davis M, Guy RT, et al. (2014)#footnote[https://doi.org/10.1371/journal.pbio.1001745]
  + Write programs for people, not computers.
  + Let the computer do the work.
  + Make incremental changes.
  + Don't repeat yourself (or others).
  + Plan for mistakes.
  + Optimize software only after it works correctly.
  + Document design and purpose, not mechanics.
  + Collaborate.
]

== The Practice of Reproducible Research: Case Studies and Lessons from the Data-Intensive Sciences
#slide[
  Quotes from chapter _Lessons Learned_, wrote by _Kathryn Huff_#footnote[https://www.ucpress.edu/books/the-practice-of-reproducible-research/paper]

  - _The case studies made clear \[...\] that humans must be incentivized to spend time on tasks intended solely for reproducibility_
  - _a lack of access to restricted data or hardware can hobble the reproducibility efforts of even the most determined scientists_
  - _portability of one's workflow is still a challenge for those intent on openness, since packaging --- especially installation of dependencies --- remains a critical stumbling block to sharing and extending work_
]

= Conclusion
== Conclusion --- REP and tools for REP in computer science
#slide[
  *Take home message*
  - Plan your experiments
  - Consider REP in your experiment design
  - Consider writing artifacts --- and evaluating them? `:)`
  - Some tools (Nix, Grid'5000...) can help

  *To go further*
  - _Scientific Methodology and Performance Evaluation for Computer Scientists_\
    https://github.com/alegrand/SMPE/
  - REP MOOCs on https://www.fun-mooc.fr/fr/cours/?query=repro
    - _Recherche reproductible : principes méthodologiques pour une science transparente_
    - _Reproducible Research II: Practices and tools for managing computations and data_
  - https://nix-tutorial.gitlabpages.inria.fr/nix-tutorial
  - https://www.grid5000.fr
]

// = Backup slides <touying:hidden>
