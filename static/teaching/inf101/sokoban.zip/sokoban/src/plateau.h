 /**
 * @file plateau.h
 * @brief Fichier d'en-tête de manipulation du plateau de jeu.
 * @details Les fichiers plateau.h et plateau.c permettent de manipuler directement le plateau de jeu.
 * plateau.h est un fichier d'en-tête : il définit l'énumération la structure Plateau et déclare
 * les différentes fonctions à compléter. La documentation des fonctions à compléter se trouve dans ce
 * fichier d'en-tête.
 */

#pragma once

#include <stdbool.h>

/**
 * @brief Représente un plateau de jeu
 * @details Les coordonnées de la grille, en deux dimensions, sont représentées par une paire d'entiers (x,y). x permet de se déplacer selon la largeur de la grille et est dans [0,largeur[. y permet de se déplacer selon la hauteur de la grille et est dans [0,hauteur[. La case d'origine (0,0) de la grille est en haut à gauche. x croît lorsqu'on va vers la droite. y croît lorsqu'on va vers le bas. La grille est stockée dans un tableau à une seule dimension. Pour transformer les coordonnées 2d (x,y) en coordonnées à une dimension (i), on utilise l'équation suivante : i = y*largeur+x. Pour effectuer la transformation inverse, on peut utiliser y = i / largeur et x = i % largeur.
 */
typedef struct
{
    int largeur;	//! La largeur de la grille
    int hauteur;	//! La hauteur de la grille
    int * grille;	//! La grille de jeu, représentée par un tableau à une seule dimension de taille largeur*hauteur. Chaque entier de ce tableau stocke la valeur d'une case du jeu.
} Plateau;

/**
 * @brief Construit un plateau
 * @details Vous devez vérifier les préconditions de cette fonction grâce à des assertions. Vous devez vous assurer que les allocations dynamiques ont fonctionné grâce à des assertions.
 * @param[in] largeur La largeur souhaitée du plateau à construire
 * @param[in] hauteur La longueur souhaitée du plateau à construire
 * @pre largeur > 0
 * @pre hauteur > 0
 * @return un pointeur vers un Plateau qui a été créé à l'intérieur de la fonction grâce à une allocation dynamique. Les champs largeur et hauteur dudit Plateau doivent avoir les bonnes valeurs en sortant de cette fonction. Le champ grille doit également avoir été créé correctement grâce à une allocation dynamique. La valeur des cases de la grille n'est pas imposée par cette fonction.
 */
Plateau * creer_plateau(int largeur, int hauteur);

/**
 * @brief Crée le plateau de jeu qui est donné dans le sujet.
 * @details Cette fonction doit appeler creer_plateau pour construire le Plateau puis est chargée de modifier la valeur des cases de la grille pour qu'elles correspondent à celles données dans le sujet. Si vous souhaitez éviter de rentrer à la main 72 cases, vous pouvez créer une chaîne de caractères représentant le plateau et vous servir de la fonction \ref valeur_depuis_caractere définie dans le fichier interface_console.h pour simplifier cette tâche.
 * @return un pointeur vers le Plateau créé dans cette fonction
 */
Plateau * creer_plateau_exemple();

/**
 * @brief Libère le plateau donné en paramètre et modifie la valeur du pointeur pour qu'il pointe désormais vers NULL.
 * @param[in,out] plateau Un pointeur vers un plateau qui est passé par pointeur, ce qui permet de modifier la valeur du pointeur à l'intérieur de cette fonction.
 */
void liberer_plateau(Plateau ** plateau);

/**
 * @brief Calcule si des coordonnées 2d (x,y) sont dans un plateau ou non
 * @param[in] plateau Le plateau
 * @param[in] x La coordonnée x
 * @param[in] y La coordonnée y
 * @return true si et seulement si (x,y) est dans plateau
 */
bool est_dans_plateau(const Plateau * plateau, int x, int y);

/**
 * @brief Permet d'obtenir la valeur d'une case d'un plateau
 * @details La précondition de cette fonction doit être vérifiée par une assertion
 * @param[in] plateau Le plateau
 * @param[in] x La coordonnée x
 * @param[in] y La coordonnée y
 * @pre (x,y) est une coordonnée valide du plateau
 * @return La valeur de la case de coordonnées (x,y) du plateau.
 */
int obtenir_case(const Plateau * plateau, int x, int y);

/**
 * @brief Permet de modifier la valeur d'une case d'un plateau
 * @details Les préconditions de cette fonction doivent être vérifiée par des assertions
 * @param[in,out] plateau Le plateau à modifier
 * @param[in] x La coordonnée x
 * @param[in] y La coordonnée y
 * @param[in] valeur La valeur à mettre dans la case de coordonnées (x,y) du plateau
 * @pre (x,y) est une coordonnée valide du plateau
 * @pre valeur est une case valide
 */
void modifier_case(Plateau * plateau, int x, int y, int valeur);

