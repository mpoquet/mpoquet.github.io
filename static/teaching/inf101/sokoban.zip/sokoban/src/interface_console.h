/**
 * @file interface_console.h
 * @brief Fichier d'en-tête de l'interface basique en console.
 * @details Les fichiers interface_console.h et interface_console.c gèrent l'interface
 * basique en mode console.
 * interface_console.h est un fichier d'en-tête : il déclare
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans ce fichier d'en-tête.
 */

#pragma once

#include "jeu.h"
#include "interface.h"

/**
 * @brief Transforme un caractère en valeur d'une case.
 * @details Cette conversion doit respecter celle définie dans le sujet. Par exemple, 'X' est un mur, '#' est un joueur sur un lieu de stockage... La postcondition de cette fonction doit être vérifiée grâce à une assertion.
 * @param[in] c Le caractère
 * @post La valeur retournée doit être une case valide
 * @return La valeur correspondante au caractère
 */
int valeur_depuis_caractere(char c);

/**
 * @brief Transforme la valeur d'une case en caractère.
 * @details Cette conversion doit respecter celle définie dans le sujet. Par exemple, 'X' est un mur, '#' est un joueur sur un lieu de stockage... La postcondition de cette fonction doit être vérifiée grâce à une assertion.
 * @param[in] valeur La valeur d'une case
 * @pre valeur doit être la représentation valide d'une case
 * @return Le caractère correspondant à la valeur donnée
 */
char caractere_depuis_valeur(int valeur);

/**
 * @brief Affiche un niveau de jeu de manière basique en mode console.
 * @details Cette fonction doit afficher le tour courant de jeu ainsi que le plateau de jeu grâce à printf.
 * @param[in] niveau Le niveau de jeu
 */
void afficher_niveau_console(const Niveau * niveau);

/**
 * @brief Récupère un choix d'action de l'utilisateur, de manière basique en mode console.
 * @details Pour ce faire, elle doit afficher les choix possibles à l'utilisateur puis saisir sa réponse. Si ce qu'a saisi l'utilisateur est invalide, il faut lui dire que ce qu'il a saisi est incorrect et lui redemander la saisie. Je vous déconseille scanf pour saisir ce qu'a rentré l'utilisateur. Préférez utiliser fgets ou une autre fonction de la bibliothèque standard. Si une erreur importante de saisie apparaît (le flux d'entrée est coupé par exemple), on peut renvoyer l'action EXIT_GAME afin de quitter le jeu.
 * @return L'action que l'utilisateur veut effectuer
 */
Action attendre_action_console();
