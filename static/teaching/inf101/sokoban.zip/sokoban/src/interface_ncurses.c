/**
 * @file interface_ncurses.c
 * @brief Fichier source de l'interface avancée en mode console, qui utilise la bibliothèque ncurses.
 * @details Les fichiers interface_ncurses.h et interface_ncurses.c gèrent l'interface
 * avancée en mode console.
 * interface_ncurses.c est un fichier source : il définit
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans le fichier d'en-tête correspondant (interface_ncurses.h).
 */

#include "interface_ncurses.h"

// #include <ncurses.h>
#include "case.h"

void afficher_valeur_ncurses(int valeur)
{

}

void initialiser_ncurses()
{

}

void finaliser_ncurses()
{

}

void afficher_niveau_ncurses(const Niveau *niveau)
{

}

Action attendre_action_ncurses()
{
    return EXIT_GAME;
}
