/**
 * @file main.c
 * @brief Fichier qui contient la fonction principale \ref main.
 */

#include <stdio.h>
#include <string.h>

#include "plateau.h"
#include "interface.h"
#include "jeu.h"

/**
 * @brief La fonction principale, c'est-à-dire le point d'entrée du programme.
 * @param argc Le nombre de paramètres envoyés au programme
 * @param argv La valeur des paramètres envoyés au programme
 * @return 0 si le programme s'est exécuté correctement, une autre valeur sinon.
 */
int main(int argc, char ** argv)
{
    // Le code qui vous est fourni vous permet de gérer les paramètres de votre programme.
    // Si vous ne spécifiez aucun paramètre, l'interface basique en mode console est utilisée.
    // Sinon, vous pouvez spécifier "ncurses" ou "sdl" afin de lancer votre programme en 
    // utilisant la bonne interface utilisateur.
    UI_type ui = CONSOLE;
    UI_data data = {NULL, NULL, NULL, NULL, NULL, NULL, NULL};

    if (argc == 2)
    {
        if (strcmp(argv[1], "console") == 0)
            ui = CONSOLE;
        else if (strcmp(argv[1], "ncurses") == 0)
            ui = NCURSES;
        else if (strcmp(argv[1], "sdl") == 0)
            ui = SDL;
        else
        {
            printf("Invalid parameter. Valid options are :\n"
                   "  console\n"
                   "  ncurses\n"
                   "  sdl\n");
            return 1;
        }
    }
    else if (argc > 2)
    {
        printf("Only one parameter is needed. Valid options are :\n"
               "  console\n"
               "  ncurses\n"
               "  sdl\n");
        return 1;
    }

    // On initialise l'interface utilisateur choisie
    initialiser_ui(ui, &data);

    // On joue au niveau qui est donné en exemple dans le sujet
    jouer_niveau_exemple(ui, &data);

    // On n'oublie pas de libérer l'interface utilisateur
    finaliser_ui(ui, &data);

    return 0;
}
