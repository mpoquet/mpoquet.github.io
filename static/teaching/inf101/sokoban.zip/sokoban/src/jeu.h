/**
 * @file jeu.h
 * @brief Fichier d'en-tête de gestion du jeu.
 * @details Les fichiers jeu.h et jeu.c permettent de gérer le jeu.
 * jeu.h est un fichier d'en-tête : il définit la structure Niveau et déclare
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans ce fichier d'en-tête.
 */

#pragma once

#include <stdbool.h>

#include "plateau.h"
#include "interface.h"

/**
 * @brief Représente un niveau de jeu.
 */
typedef struct niveau_t
{
    Plateau * plateau;	//! Le plateau de jeu.
    int tour_actuel;	//! Le tour actuel. Lorsqu'on commence à jouer ou qu'on réinitialise le jeu, on doit être au tour 1.
    int x_joueur;		//! La coordonnée x où le joueur se trouve dans le plateau de jeu.
    int y_joueur;		//! La coordonnée y où le joueur se trouve dans le plateau de jeu.
} Niveau;

/**
 * @brief Construit un niveau qui correspond à celui donné dans le sujet.
 * @details Cette fonction doit construire un Niveau par allocation dynamique, construire son plateau en appelant la fonction \ref creer_plateau_exemple et initialiser les autres champs du Niveau (tour_actuel, x_joueur et y_joueur) aux bonnes valeurs. Vous devez vous assurer que l'allocation dynamique a fonctionné grâce à une assertions.
 * @return Un pointeur vers le niveau créé dynamiquement dans la fonction.
 */
Niveau * creer_niveau_exemple();

/**
 * @brief Libère le niveau donné en paramètre et modifie la valeur du pointeur pour qu'il pointe désormais vers NULL.
 * @details Cette fonction doit libérer le plateau de jeu grâce à la fonction \ref liberer_plateau puis libérer le niveau lui-même, avant de mettre ce pointeur à NULL pour éviter de futurs bugs.
 * @param[in,out] niveau Un pointeur vers un niveau qui est passé par pointeur, ce qui permet de modifier la valeur du pointeur à l'intérieur de cette fonction.
 */
void liberer_niveau(Niveau ** niveau);

/**
 * @brief Effectue une action de déplacement dans le niveau
 * @details Cette fonction doit modifier le plateau de jeu de telle sorte que le mouvement souhaité soit effectué. Si le mouvement est invalide (si un joueur souhaite fonce dans un mur ou pousse une caisse vers un mur ou une autre caisse), le plateau de jeu doit rester identique.
 * @param[in,out] niveau Le niveau de jeu.
 * @param[in] action L'action de mouvement à effectuer.
 * @pre L'action est MOVE_LEFT ou MOVE_RIGHT ou MOVE_UP ou MOVE_DOWN.
 */
void effectuer_deplacement(Niveau * niveau, Action action);

/**
 * @brief Permet de savoir si un niveau est terminé ou non.
 * @details Un niveau est terminé lorsque toutes les caisses sont sur un lieu de stockage.
 * @param niveau Le niveau à tester
 * @return true si et seulement si le niveau est terminé, c'est-à-dire que toutes les caisses sont sur un lieu de stockage.
 */
bool est_niveau_termine(const Niveau * niveau);

/**
 * @brief Permet de jouer au niveau de l'exemple du sujet.
 * @details Cette fonction est la fonction principale pour jouer au niveau de l'exemple. Elle doit créer un niveau correspondant à l'exemple et gérer les tours de jeu jusqu'à ce que le niveau soit terminé ou que l'utilisateur souhaite quitter le jeu. Attention : il faut libérer le niveau créé avant de quitter cette fonction.
 * @param[in] ui Le type d'interface utilisée
 * @param[in,out] data Les données associées à l'interface
 * @return Le nombre de tours utilisés pour faire le niveau s'il a été terminé. Si l'utilisateur a quitté le niveau, la fonction doit renvoyer -1.
 */
int jouer_niveau_exemple(UI_type ui, UI_data *data);


