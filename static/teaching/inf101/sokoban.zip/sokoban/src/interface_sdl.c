/**
 * @file interface_sdl.c
 * @brief Fichier source de l'interface graphique, qui utilise la bibliothèque SDL.
 * @details Les fichiers interface_sdl.h et interface_sdl.c gèrent l'interface graphique.
 * interface_sdl.c est un fichier source : il définit
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans le fichier d'en-tête correspondant (interface_sdl.h).
 */

#include "interface_sdl.h"

// #include <SDL/SDL.h>
// #include <SDL/SDL_image.h>

#include "case.h"

// SDL_Surface *charger_image(const char *nom_fichier)
// {
//     return NULL;
// }

void initialiser_sdl(UI_data *data)
{

}

void finaliser_sdl(UI_data *data)
{

}

void afficher_niveau_sdl(const Niveau *niveau, const UI_data * data)
{

}

Action attendre_action_sdl(UI_data *data)
{
    return EXIT_GAME;
}


