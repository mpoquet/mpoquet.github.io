/**
 * @file interface_console.c
 * @brief Fichier source de l'interface basique en console.
 * @details Les fichiers interface_console.h et interface_console.c gèrent l'interface
 * basique en mode console.
 * interface_console.c est un fichier source : il définit
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans le fichier d'en-tête correspondant (interface_console.h).
 */

#include "interface_console.h"
#include "case.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "jeu.h"

int valeur_depuis_caractere(char c)
{
    return 0;
}

char caractere_depuis_valeur(int valeur)
{
    return '\0';
}

void afficher_niveau_console(const Niveau * niveau)
{

}

Action attendre_action_console()
{
    return EXIT_GAME;
}
