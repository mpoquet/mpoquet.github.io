/**
 * @file interface.c
 * @brief Fichier source de l'interface utilisateur.
 * @details Les fichiers interface.h et interface.c gèrent les différentes interfaces utilisateur.
 * Les fonctions de ces fichiers servent à appeler les différentes interfaces utilisateur.
 * interface.c est un fichier source : il définit
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans le fichier d'en-tête correspondant (interface.h).
 */

#include "interface.h"
#include "interface_console.h"
#include "interface_ncurses.h"
#include "interface_sdl.h"

void initialiser_ui(UI_type type, UI_data *data)
{
}

void afficher_niveau(const Niveau *niveau, UI_type type, const UI_data *data)
{
}

Action attendre_action(UI_type type, UI_data *data)
{
    return EXIT_GAME;
}

void finaliser_ui(UI_type type, UI_data *data)
{
}
