/**
 * @file interface.h
 * @brief Fichier d'en-tête de l'interface utilisateur.
 * @details Les fichiers interface.h et interface.c gèrent les différentes interfaces utilisateur.
 * Les fonctions de ces fichiers servent à appeler les différentes interfaces utilisateur.
 * interface.h est un fichier d'en-tête : il déclare
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans ce fichier d'en-tête.
 */

#pragma once

// #include <SDL/SDL.h>

// La ligne suivante est une forward declaration (déclaration anticipée).
// Cela permet de contourner le problème de collision d'inclusions entre
// interface.h et jeu.h
typedef struct niveau_t Niveau;

/**
 * @brief Énumère les différents types d'interface utilisateur.
 */
typedef enum
{
    CONSOLE     //!< L'interface basique en mode console
    ,NCURSES    //!< L'interface avancée en mode console qui utilise la bibliothèque ncurses
    ,SDL        //!< L'interface en mode graphique qui utilise la bibliothèque
    ,IA         //!< Le joueur n'est pas contrôlé par l'utilisateur mais pas une intelligence artificielle
} UI_type;

/**
 * @brief Permet de stocker des données liées à l'interface utilisateur.
 * @details De telles données ne devraient être utiles que pour l'interface graphique qui utilise la SDL.
 */
typedef struct
{
    // SDL_Surface * screen;       //! La surface qui représente la fenêtre
    // SDL_Surface * crate;        //! La surface d'une caisse
    // SDL_Surface * crate_ok;     //! La surface d'une caisse sur un lieu de stockage
    // SDL_Surface * player;       //! La surface d'un joueur
    // SDL_Surface * player_ok;    //! La surface d'un joueur sur un lieu de stockage
    // SDL_Surface * storage;      //! La surface d'un lieu de stockage
    // SDL_Surface * wall;         //! La surface d'un mur
} UI_data;

/**
 * @brief Énumère les actions que l'utilisateur peut effectuer.
 */
typedef enum
{
    MOVE_LEFT       //!< L'utilisateur souhaite déplacer le joueur vers la gauche
    ,MOVE_RIGHT     //!< L'utilisateur souhaite déplacer le joueur vers la droite
    ,MOVE_UP        //!< L'utilisateur souhaite déplacer le joueur vers le haut
    ,MOVE_DOWN      //!< L'utilisateur souhaite déplacer le joueur vers le bas
    ,RESET_LEVEL    //!< L'utilisateur souhaite réinitialiser le niveau en cours
    ,EXIT_GAME      //!< L'utilisateur souhaite quitter le jeu
} Action;

/**
 * @brief Initialise l'interface utilisateur.
 * @details Cette fonction ne fait rien lorsqu'on utilise l'interface basique en mode console. Elle doit par contre appeler les fonctions \ref initialiser_ncurses ou \ref initialiser_sdl lorsqu'on se sert respectivement de l'interface avancée en mode console ou de l'interface graphique.
 * @param[in] type Le type d'interface utilisé
 * @param[in,out] data Les données associées à l'interface utilisateur. Ces données sont passées par pointeur afin de permettre de les modifier si c'est nécessaire (lorsqu'on utilise l'interface graphique par exemple).
 */
void initialiser_ui(UI_type type, UI_data * data);

/**
 * @brief Finalise l'interface utilisateur.
 * @details Cette fonction ne fait rien lorsqu'on utilise l'interface basique en mode console. Elle doit par contre appeler les fonctions \ref finaliser_ncurses ou \ref finaliser_sdl lorsqu'on se sert respectivement de l'interface avancée en mode console ou de l'interface graphique.
 * @param[in] type Le type d'interface utilisé
 * @param[in,out] data Les données associées à l'interface utilisateur. Ces données sont passées par pointeur afin de permettre de les modifier si c'est nécessaire (lorsqu'on utilise l'interface graphique par exemple).
 */
void finaliser_ui(UI_type type, UI_data * data);

/**
 * @brief Affiche un niveau.
 * @details Cette fonction doit appeler la bonne interface pour afficher le niveau de jeu. Elle doit appeler \ref afficher_niveau_console ou \ref afficher_niveau_ncurses ou \ref afficher_niveau_sdl si on utilise respectivement l'interface basique en mode console, l'interface avancée qui utilise ncurses ou l'interface graphique qui utilise la SDL.
 * @param[in] niveau Le niveau à afficher
 * @param[in] type Le type d'interface utilisé
 * @param[in,out] data Les données associées à l'interface utilisateur. Ces données sont passées par pointeur afin de permettre de les modifier si c'est nécessaire.
 */
void afficher_niveau(const Niveau * niveau, UI_type type, const UI_data * data);

/**
 * @brief Attend une action de l'utilisateur et la renvoie.
 * @details Cette fonction doit appeler la bonne interface pour récupérer une action depuis l'utilisateur. Elle doit appeler \ref attendre_action_console ou \ref attendre_action_ncurses ou \ref attendre_action_sdl si on utilise respectivement l'interface basique en mode console, l'interface avancée qui utilise ncurses ou l'interface graphique qui utilise la SDL.
 * @param[in] type Le type d'interface utilisé
 * @param[in,out] data Les données associées à l'interface utilisateur. Ces données sont passées par pointeur afin de permettre de les modifier si c'est nécessaire.
 */
Action attendre_action(UI_type type, UI_data * data);
