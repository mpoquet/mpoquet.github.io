/**
 * @file case.c
 * @brief Fichier source de manipulation des cases.
 * @details Les fichiers case.h et case.c permettent de manipuler directement les cases.
 * case.c est un fichier source : il définit les fonctions déclarées dans
 * le fichier d'en-tête correspondant (case.h). La documentation des fonctions
 * à compléter se trouve dans le fichier case.h
 */

#include "case.h"

bool est_caisse(int valeur)
{
    return false;
}

bool est_joueur(int valeur)
{
    return false;
}

bool est_mur(int valeur)
{
    return false;
}

bool est_stockage(int valeur)
{
    return false;
}


bool est_case_valide(int valeur)
{
	return false;
}

int ajouter_caisse(int valeur)
{
    return 0;
}

int ajouter_joueur(int valeur)
{
    return 0;
}

int retirer_caisse(int valeur)
{
    return 0;
}

int retirer_joueur(int valeur)
{
    return 0;
}

