/**
 * @file interface_ncurses.h
 * @brief Fichier d'en-tête de l'interface avancée en console, qui utilise la bibliothèque ncurses.
 * @details Les fichiers interface_ncurses.h et interface_ncurses.c gèrent l'interface
 * avancée en mode console.
 * interface_ncurses.h est un fichier d'en-tête : il déclare
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans ce fichier d'en-tête.
 */

#pragma once

#include "jeu.h"
#include "interface.h"

/**
 * @brief Affiche la valeur d'une case grâce à la bibliothèque ncurses.
 * @details On suppose que le curseur de ncurses est bien placé lorsqu'on appelle cette fonction. L'affichage des cases doit respecter celui indiqué dans le sujet. Par exemple, un joueur sur un lieu de stockage doit être affiché par deux ':' blancs sur fond rouge.
 * @param[in] valeur La valeur de la case à afficher
 */
void afficher_valeur_ncurses(int valeur);

/**
 * @brief Initialise la bibliothèque ncurses.
 * @details Cette fonction doit activer certains modes de ncurses, par exemple appeler noecho()...
 */
void initialiser_ncurses();

/**
 * @brief Finalise la bibliothèque ncurses.
 * @details Cette fonction doit désactiver les modes de ncurses activés dans \ref initialiser_ncurses, afin que le terminal soit dans un état correct lorsqu'on quitte le programme.
 */
void finaliser_ncurses();

/**
 * @brief Affiche un niveau grâce à la bibliothèque ncurses
 * @details Cette fonction est chargée d'afficher le tour de jeu courant ainsi que d'afficher le plateau de jeu. Elle doit pour cela bien placer le curseur et appeler la fonction \ref afficher_valeur_ncurses.
 * @param[in] niveau Le niveau à afficher
 */
void afficher_niveau_ncurses(const Niveau * niveau);

/**
 * @brief Attend une action de l'utilisateur grâce à la bibliothèque ncurses
 * @details Les actions possibles sont définies par des pressions sur certaines touches (cf. sujet). Par exemple, appuyer sur 'q' quitte le programme, appuyer sur la flèche du haut fait se déplacer le joueur vers le haut...
 * @return L'action choisie par l'utilisateur.
 */
Action attendre_action_ncurses();
