/**
 * @file case.h
 * @brief Fichier d'en-tête de manipulation des cases.
 * @details Les fichiers case.h et case.c permettent de manipuler directement les cases.
 * case.h est un fichier d'en-tête : il définit l'énumération Case et déclare
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans ce fichier d'en-tête.
 */

#pragma once

#include <stdbool.h>

/**
 * @brief Définit les différents flags permettant de représenter une case (cf. sujet)
 * @details Une case est définie par un entier, composé de différents flags définis
 */
typedef enum
{
    CAISSE = 0x01       //!< Ce flag est mis si et seulement si la case contient une caisse
    ,JOUEUR = 0x02      //!< Ce flag est mis si et seulement si la case contient un joueur
    ,MUR = 0x04         //!< Ce flag est mis si et seulement si la case contient un mur
    ,STOCKAGE = 0x08    //!< Ce flag est mis si et seulement si la case est un lieu de stockage pour caisses
}  Case;

/**
 * @brief Calcule si une case contient une caisse ou non
 *
 * @param[in] valeur Une valeur entière représentant une case.
 * @return true si et seulement si la case contient une caisse
 */
bool est_caisse(int valeur);

/**
 * @brief Calcule si une case contient un joueur ou non
 * @param[in] valeur Une valeur entière représentant une case.
 * @return true si et seulement si la case contient un joueur
 */
bool est_joueur(int valeur);

/**
 * @brief Calcule si une case contient un mur ou non
 * @param[in] valeur Une valeur entière représentant une case.
 * @return true si et seulement si la case contient un mur
 */
bool est_mur(int valeur);

/**
 * @brief Calcule si une case contient un lieu de stockage ou non
 * @param[in] valeur Une valeur entière représentant une case.
 * @return true si et seulement si la case contient un lieu de stockage
 */
bool est_stockage(int valeur);

/**
 * @brief Calcule si une valeur est une représentation valide d'une caisse ou non.
 * @details Cette fonction peut vous permettre de vérifier facilement si votre manipulation des cases est valide ou non
 * @param[in] valeur La valeur à tester
 * @return true si et seulement si la valeur est une représentation valide d'une caisse. Les représentations valides sont : une case vide, un mur, un lieu de stockage, un joueur, un joueur sur un lieu de stockage, une caisse, une caisse sur un lieu de stockage. Pour toute autre combinaison des flags, cette fonction doit renvoyer false. Si la valeur contient d'autres bits que ceux indiqués dans les flags de l'énumération Case, cette fonction doit renvoyer false.
 */
bool est_case_valide(int valeur);


/**
 * @brief Calcule la nouvelle valeur d'une case après qu'une caisse y ait été ajoutée
 * @param[in] valeur L'ancienne valeur de la case
 * @return La nouvelle valeur de la case, qui doit correspondre à l'ancienne case sur laquelle une caisse vient d'arriver
 */
int ajouter_caisse(int valeur);

/**
 * @brief Calcule la nouvelle valeur d'une case après qu'un joueur y ait été ajouté
 * @param[in] valeur L'ancienne valeur de la case
 * @return La nouvelle valeur de la case, qui doit correspondre à l'ancienne case sur laquelle un joueur vient d'arriver
 */
int ajouter_joueur(int valeur);

/**
 * @brief Calcule la nouvelle valeur d'une case après qu'une caisse ait été retirée de la case
 * @param[in] valeur L'ancienne valeur de la case
 * @return La nouvelle valeur de la case, qui doit correspondre à l'ancienne case sur laquelle une caisse vient d'être retirée
 */
int retirer_caisse(int valeur);

/**
 * @brief Calcule la nouvelle valeur d'une case après qu'un joueur ait été retiré de la case
 * @param[in] valeur L'ancienne valeur de la case
 * @return La nouvelle valeur de la case, qui doit correspondre à l'ancienne case sur laquelle un joueur vient d'être retiré
 */
int retirer_joueur(int valeur);
