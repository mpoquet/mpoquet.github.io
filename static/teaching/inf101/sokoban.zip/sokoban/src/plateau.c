 /**
 * @file plateau.c
 * @brief Fichier source de manipulation du plateau de jeu.
 * @details Les fichiers plateau.h et plateau.c permettent de manipuler directement le plateau de jeu.
 * plateau.c est un fichier source : il définit les différentes fonctions à compléter.
 * La documentation des fonctions à compléter se trouve dans le fichier d'en-tête correspondant (plateau.h).
 */

#include "plateau.h"

#include <stdlib.h>
#include <assert.h>

#include "interface_console.h"

Plateau * creer_plateau(int largeur, int hauteur)
{
    return NULL;
}

Plateau * creer_plateau_exemple()
{
    return NULL;
}

void liberer_plateau(Plateau ** plateau)
{

}

int obtenir_case(const Plateau * plateau, int x, int y)
{
    return 0;
}

void modifier_case(Plateau * plateau, int x, int y, int valeur)
{

}

bool est_dans_plateau(const Plateau *plateau, int x, int y)
{
    return false;
}
