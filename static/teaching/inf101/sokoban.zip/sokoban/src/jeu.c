/**
 * @file jeu.c
 * @brief Fichier source de gestion du jeu.
 * @details Les fichiers jeu.h et jeu.c permettent de gérer le jeu.
 * jeu.c est un fichier source : il définit les fonctions déclarées dans
 * le fichier d'en-tête correspondant (jeu.h). La documentation des fonctions
 * à compléter se trouve dans le fichier jeu.h.
 */

#include "jeu.h"
#include "case.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

Niveau * creer_niveau_exemple()
{
    return NULL;
}

void liberer_niveau(Niveau **jeu)
{

}

int jouer_niveau_exemple(UI_type ui, UI_data * data)
{
    return -1;
}

bool est_niveau_termine(const Niveau *niveau)
{
    return false;
}


void effectuer_deplacement(Niveau *niveau, Action action)
{

}
