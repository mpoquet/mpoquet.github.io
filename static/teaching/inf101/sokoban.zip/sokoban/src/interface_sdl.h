/**
 * @file interface_sdl.h
 * @brief Fichier d'en-tête de l'interface graphique, qui utilise la bibliothèque SDL.
 * @details Les fichiers interface_sdl.h et interface_sdl.c gèrent l'interface graphique.
 * interface_sdl.h est un fichier d'en-tête : il déclare
 * les différentes fonctions à compléter. La documentation des fonctions à
 * compléter se trouve dans ce fichier d'en-tête.
 */

#pragma once

#include "jeu.h"
#include "interface.h"

/*
 * @brief Charge une image depuis un fichier.
 * @details Cette fonction doit pour cela appeler la fonction IMG_Load de la SDL et renvoyer l'image ainsi chargée si c'est possible. Si l'image n'a pas pu être chargée, on peut afficher un message d'erreur grâce à la fonction printf et quitter le programme grâce à la fonction exit.
 * @param[in] nom_fichier Le nom du fichier depuis lequel l'image doit être chargée
 * @return La surface SDL correspondant à l'image chargée depuis le fichier.
 */
// SDL_Surface * charger_image(const char * nom_fichier);

/**
 * @brief Initialise l'interface graphique.
 * @details Cette fonction doit initialiser la SDL (SDL_Init) ainsi que les drivers permettant de lire les images (IMG_Init). Cette fonction doit également créer une fenêtre et la placer dans data->screen. S'il est impossible de créer une fenêtre, un message d'erreur doit être affiché grâce à la fonction printf et le programme quitté grâce à la fonction exit. Cette fonction doit également mettre un titre à la fenêtre et charges les différentes images dont vous aurez besoin grâce à la fonction \ref charger_image.
 * @param[in,out] data Les données associées à l'interface utilisateur
 */
void initialiser_sdl(UI_data * data);

/**
 * @brief Finalise l'interface graphique.
 * @details Cette fonction doit libérer toutes les images chargées dans \ref initialiser_sdl. Elle peut également appeler
 * la fonction SDL_Quit().
 * @param[in,out] data Les données associées à l'interface utilisateur.
 */
void finaliser_sdl(UI_data * data);

/**
 * @brief Affiche un niveau de jeu grâce à la SDL
 * @details Cette fonction doit afficher le plateau de jeu dans la fenêtre, notamment grâce aux fonctions SDL_FillRect et SDL_BlitSurface. Vous pouvez afficher le tour courant de jeu comme vous le souhaitez, je l'ai par exemple mis dans le titre de la fenêtre mais vous pouvez faire quelque chose de plus sympathique si vous le souhaitez.
 * @param[in] niveau Le niveau à afficher
 * @param[in] data Les données associées à l'interface utilisateur
 */
void afficher_niveau_sdl(const Niveau * niveau, const UI_data * data);

/**
 * @brief Attend une action de l'utilisateur grâce à la SDL.
 * @details Les actions possibles sont définies par des pressions sur certaines touches (cf. sujet). Par exemple, appuyer sur 'q' quitte le programme, appuyer sur la flèche du haut fait se déplacer le joueur vers le haut... Vous pouvez vous servir de la fonction SDL_WaitEvent pour faire cela.
 * @param[in,out] data Les données associées à l'interface utilisateur
 * @return L'action choisie par l'utilisateur
 */
Action attendre_action_sdl(UI_data * data);
