#!/usr/bin/env Rscript
library(tidyverse)
library(viridis)

grisou = read_csv("grisou-real.csv") %>% transmute (
  uuid = uuid,
  nb_noise_conn = total_connection_tcp,
  runtime = mpi_runtime,
  name = "real"
)
simu_ptask = read_csv("number_of_connections.all.csv") %>%
  filter(application_type == "ptask" & model == "Ptask_L07") %>%
  transmute (
    nb_noise_conn = number_of_connections,
    runtime = runtime_predicted,
    name = "ptask"
  )
simu_smpi = read_csv("number_of_connections.all.csv") %>%
  filter(application_type == "smpi" & model == "SMPI default") %>%
  transmute (
    nb_noise_conn = number_of_connections,
    runtime = runtime_predicted,
    name = "smpi"
  )
simu_bmf = read_csv("number_of_connections.BMF.csv") %>%
  transmute (
    nb_noise_conn = number_of_connections,
    runtime = runtime_predicted,
    name = "ptask-bmf"
  )

bind_rows(simu_ptask, simu_smpi, grisou) %>%
  ggplot() +
  geom_point(aes(x=nb_noise_conn, y=runtime, color=name, shape=name)) +
  theme_bw() +
  theme(legend.position="top") +
  labs(x="Number of connections in noise", y="Application runtime (s)", color="Application", shape="Application") +
  scale_color_viridis(discrete=TRUE, end=0.8)
ggsave("./ptask-vs-grisou.pdf", width=3.5, height=4)
ggsave("./ptask-vs-grisou-fullscreen.pdf", width=6, height=3.25)

bind_rows(simu_bmf, simu_smpi, grisou) %>%
  ggplot() +
  geom_point(aes(x=nb_noise_conn, y=runtime, color=name, shape=name)) +
  theme_bw() +
  labs(x="Number of connections in noise", y="Application runtime (s)", color="Application", shape="Application") +
  scale_color_viridis(discrete=TRUE, end=0.8)
ggsave("./ptask-bmf-vs-grisou.pdf", width=8, height=4)
