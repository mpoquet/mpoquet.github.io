---
title: "Coarse-Grained Simulation for Resource Management of Distributed Systems"
author: Millian Poquet
bibliography: biblio.bib
theme: Estonia
date: 2022-04-27
lang: en
classoption:
- aspectratio=169
header-includes:
- |
  ```{=latex}
  \usepackage[backend=biber, style=alphabetic, sorting=none]{biblatex}
  \usepackage{subcaption}
  \hypersetup{colorlinks,linkcolor=,citecolor=colorbrewer-orange}
  \setbeamertemplate{footline}[frame number]
  \renewcommand\dots{\ifmmode\ldots\else\makebox[1em][c]{.\hfil.\hfil.}\thinspace\fi}
  \hypersetup{colorlinks,linkcolor=,urlcolor=estonian-blue}
  \graphicspath{{./fig/},{./img/}}
  \addbibresource{biblio.bib}

  % Fix pandoc shenanigans
  \setbeamertemplate{section page}{}
  \setbeamertemplate{subsection page}{}
  \AtBeginSection{}
  \AtBeginSubsection{}

  \newcommand\blfootnote[1]{%
    \begingroup
    \renewcommand\thefootnote{}\footnote{\hspace*{-5mm}#1}%
    \addtocounter{footnote}{-1}%
    \endgroup
  }
  ```
---

# Introduction

### Study distributed systems and applications
Many distributed systems in use today or tomorrow (HPC, Clouds, Edge, Fog...)

Resource management for many issues (energy, fault tolerance, scheduling, scalability, heterogeneity...)

Methodological experimental approaches

- Direct experimentation (real applications on real platforms)
- Simulation (application prototypes on platforms models)
- Something in between (emulation, partial simulation...)

### Building simulators from scratch is risky

How useful is a simulator whose results cannot be trusted?

- Models validated?
- Implementation tested?
- Model instantiation evaluated?

**Doing it thoroughly may take (dozens of) years!**

\vspace{5mm}
Using a validated simulation framework helps a lot

- Thoroughly validated models
- Thoroughly tested implementation
- Model instantiation responsibility is still on you

### Promising simulation framework for resource management?
Convenient API but bad models (PeerSim, GridSim, CloudSim...)

- No hope to observe complex phenomena

\vspace{2mm}
Packet-level network simulators (NS-3, INSEE...)

- Fine granularity $\rightarrow$ does not scale for concurrent jobs / large systems
- Usable for special cases — *e.g.*, interference-free placements \cite{pascual2015locality}
- No model for other resources (CPUs, storages...)

\vspace{2mm}
Flow-level versatile simulator (SimGrid)

- Tunable granularity, scales
- Models for main types of resources (network, CPUs, storages)
- Power consumption models based on resource usage

``` {=latex}
\end{frame}
\begin{frame}{Table of Contents}
  \tableofcontents[hideallsubsections]
```

# SimGrid
### Overview
Simulation framework around distributed platforms and applications

\vspace{2mm}
Main use cases
\vspace*{-2mm}

- Prototype systems or algorithms
- Evaluate various platform topologies/configurations
- Study existing distributed app (create digital twin)

\vspace{2mm}
Key features
\vspace*{-2mm}

- Sound/accurate models: theoretically and experimentally evaluated
- Scalable: fast models and implementations
- Usable: LGPL, linux/mac/windows, C++ Python and Java

### Overview (2)
Numbers

- Exists since early 2001, development still very active
- $\approx$ 200k lines of C/C++ code
- $\approx$ 32k commits
- Used in at least 532 scientific articles

Community

- 4 main developers
- Many power users (current/previous PhD. students...)
- Get help easily (documentation, mattermost, mailing list...)
- Your contributions can be merged

### Architecture

How to build your simulator?

- Use one of the SimGrid interfaces
- Link the SimGrid library with your code

\vspace{5mm}
Available interfaces

- \makebox[12mm][l]{\textbf{S4U}} write your own simulator (actors, messages), C++ C or Python
- \makebox[12mm][l]{MSG} older brother of S4U, C or Java
- \makebox[12mm][l]{MC} verify properties on your application *model* (model is code)
- \makebox[12mm][l]{SMPI} `smpicc`/`smpirun` on your real MPI app
- \makebox[12mm][l]{\textbf{RSG}} emulate distributed memory apps (S4U-like API)
- \makebox[12mm][l]{\textbf{Batsim}} study resource management (higher-level)

## Models
### Platform and network models
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  Platform = graph of hosts and links

  \vspace{2mm}
  Hosts: computational resources
  \begin{itemize}
    \item Speed (FLOP per second)
  \end{itemize}

  \vspace{3mm}
  Links: network resources \\
  (cables, switches, routers...)
  \begin{itemize}
    \item Latency (seconds)
    \item Bandwidth (bytes per second)
  \end{itemize}

  \vspace{3mm}
  Several network models available
  \begin{itemize}
    \item Fast flow-level: slow start, TCP congestion, cross-traffic
    \item Constant time: a bit faster (unrealistic)
    \item Packet-level: NS-3 binding
  \end{itemize}
\end{column}
\begin{column}{0.52\textwidth}
  \vspace{6mm}
  \hspace*{-4mm}\includegraphics[width=1.08\textwidth]{platform.pdf}
\end{column}
\end{columns}
```

### Actors, computations and communications
Actors

- One of the simulation \textit{actors} — AKA agent, thread, process...
- Executes user-given code on a Host
- User-given code may contain SimGrid calls

\vspace{5mm}
Main SimGrid calls

- Compute $x$ flops on current host
- Send $x$ bytes to an actor/host/mailbox
- Yield (just interrupt control flow)

### S4U simulator example (Python)

```{=latex}
{\footnotesize
```

~~~~ {#mycode .py}
from simgrid import Actor, Engine, Host, this_actor

def sleeper():
    this_actor.info("Sleeper started")
    this_actor.sleep_for(1)
    this_actor.info("I'm done. See you!")

def master():
    this_actor.execute(64)
    actor = Actor.create("sleeper", Host.current(), sleeper)
    this_actor.info("Join sleeper (timeout 2)")
    actor.join(2)

if __name__ == '__main__':
    e = Engine(sys.argv)
    e.load_platform(sys.argv[1])
    Actor.create("master", Host.by_name("Tremblay"), master)
    e.run()
~~~~~~~~~~~~~~~~~~~~~~~

```{=latex}
}
```

### Actor execution model
```{=latex}
\begin{columns}
\begin{column}{0.39\textwidth}
  Main points
  \begin{itemize}
    \item mutual exclusion on actors
    \item \textit{maestro} dictates who run
          (deterministic)
    \item SG calls $\approx$ syscalls
    \begin{itemize}
      \item interruption points inside user-given functions
    \end{itemize}
  \end{itemize}

  \vspace{7mm}
  Various implementations
  \begin{itemize}
    \item pthread: \textit{easy} debug, slow
    \item asm: blazing fast
    \item ucontext, boost context...
  \end{itemize}
\end{column}
\begin{column}{0.6\textwidth}
  \vspace{10mm}
  \includegraphics[width=\textwidth]{sg-kernel-actors.pdf}
\end{column}
\end{columns}
```

### Energy model (DVFS)
- Resources have *power states* (DVFS)
- SimGrid: Manually switch pstates, which change the flop rate
- For one pstate, consumption = linear function of CPU use (+ idle jump)

```{=latex}
\centering
\vspace*{-1mm}
\includegraphics[width=0.67\textwidth]{cost-model-xkcd.pdf}
```

### Energy model (ON/OFF)

ON $\leftrightarrow$ OFF takes time (seconds) and energy (Joules)

```{=latex}
\begin{center}
    \includegraphics[width=.8\linewidth]{power-states-graph.pdf}
\end{center}
```

- Not easy for the noise:
  everybody wants something specific
- SimGrid provides basic mechanisms,
  you have to help yourself
- Switching ON/OFF is instantaneous

``` {=latex}
\end{frame}
\section{Batsim}
\begin{frame}{Table of Contents}
  \tableofcontents[currentsection,hideallsubsections]
```

### Overview
Resource management simulator built on top of SimGrid

Main use cases

- Analyze and compare online resource management algorithms
- Workload/platform dimensioning

Key features

- Prototype scheduling algorithms in any programming language
- Or use real schedulers (done on OAR and K8s, prototypes for flux/slurm)
- Several job models (tunable level of realism) without deep SimGrid knowledge

### Overview (2)
Numbers

- Exists since 2015
- $\approx$ 9k lines of C++ code
- $\approx$ 2k commits

Community

- 1-2 main developers at the same time
- Get help easily (documentation, mattermost, mailing list)
- Users are mostly from scientific labs (international), companies

### Architecture
```{=latex}
\begin{center}
\includegraphics[height=.9\textheight]{batsim-rjms-overview.pdf}
\end{center}
```

<!-- ### Architecture (2)
```{=latex}
\begin{center}
\includegraphics[height=.9\textheight]{batsim-archi3d.pdf}
\end{center}
``` -->

### Protocol
```{=latex}
\begin{columns}
\begin{column}{0.55\textwidth}
  \includegraphics[width=\textwidth]{batproto-request-reply.pdf}
\end{column}
\begin{column}{0.4\textwidth}
  Classical scheduling events
  \begin{itemize}
    \item Job submitted
    \item Job finished
  \end{itemize}

  \vspace{3mm}
  Resource management decisions
  \begin{itemize}
    \item Execute job $j$ on $M = \{ 1, 2 \}$
    \item Shutdown $M = \{3, ..., 5\}$
  \end{itemize}

  \vspace{3mm}
  Simulation/monitoring control
  \begin{itemize}
    \item Call scheduler at $t=120$
    \item How much energy used?
    \item How much data moved?
  \end{itemize}

\end{column}
\end{columns}
```

## Models
### Platform
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  SimGrid platform + some sugar

  \vspace{7mm}
  RJMS internals on \textit{master} host

  \vspace{7mm}
  Disks modeled as speed=0 hosts
  \begin{itemize}
    \item Enables parallel task use
  \end{itemize}
\end{column}
\begin{column}{0.52\textwidth}
  \vspace{7mm}
  \includegraphics[width=\textwidth]{platform-io.pdf}
\end{column}
\end{columns}
```

### Jobs and profiles
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  Jobs : scheduler view
  \begin{itemize}
    \item User resource request
    \item (Walltime)
    \item Simulation profile
  \end{itemize}

  \vspace{3mm}
  Profiles : simulator view
  \begin{itemize}
    \item How to simulate the app?
  \end{itemize}

  \vspace{3mm}
  Profile types
  \begin{itemize}
    \item Fixed length
    \item Parallel task
    \item Trace replay (MPI...)
    \item Composition (seq., parallel)
    \item Convenient shortcuts
    \begin{itemize}
      \item IO transfers (alone)
      \item IO transfers (along task)
    \end{itemize}
  \end{itemize}
\end{column}
\begin{column}{0.52\textwidth}
  %\vspace{7mm}
  \includegraphics[width=.95\textwidth]{ptask-and-sequence.pdf}
\end{column}
\end{columns}
```

### Application model example: Stencil with checkpoints
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  \begin{enumerate}
    \item Loads data from parallel filesystem
    \item Iteration: local computations, exchange data with neighbors
    \item Every 100 iterations: dump checkpoint on parallel file system
    \item Stop after 1000 iterations.
  \end{enumerate}

  \vspace{3mm}
  \begin{center}
    \includegraphics[width=.5\textwidth]{stencil-ranks.pdf}
  \end{center}
\end{column}
\begin{column}{0.52\textwidth}
  Profile example
  \begin{itemize}
    \item Bundle 100 iterations in 1 parallel task
  \end{itemize}
  \vspace{5mm}
  \begin{center}
    \includegraphics[width=.6\textwidth]{stencil-profiles.pdf}
  \end{center}
\end{column}
\end{columns}
```

### Application model example: Stencil with checkpoints (code)

```{=latex}
{\tiny
```

~~~ {#mycode .json}
{ "initial_load": {
    "type": "parallel_homogeneous_pfs",
    "bytes_to_read": 67108864,
    "bytes_to_write": 0,
    "storage": "pfs" },
  "100_iterations": {
    "type": "parallel",
    "cpu": [   1e9,    1e9,    1e9,    1e9],
    "com": [     0, 819200, 819200,      0,
            819200,      0,      0, 819200,
            819200,      0,      0, 819200,
                 0, 819200, 819200,      0] },
  "checkpoint": {
    "type": "parallel_homogeneous_pfs",
    "bytes_to_read": 0,
    "bytes_to_write": 67108864,
    "storage": "pfs" },
  "iterations_and_checkpoints": {
    "type": "composed",
    "repeat": 10,
    "seq": ["100_iterations", "checkpoint"] },
  "imaginary_stencil": {
    "type": "composed",
    "repeat": 1,
    "seq": ["initial_load", "iterations_and_checkpoints"] }
}
~~~

```{=latex}
}
```

## Ecosystem and Usage
### Ecosystem and Usage
\vspace*{-2mm}
Ecosystem
\vspace*{-2mm}

- Set of scheduling algorithms (C++, Python, Rust, D, Perl...)
- Tools to generate platforms and workloads
- (Interactive) tools to visualize/analyze Batsim results
- Tools to help experiments (environment control, execution...)

Already used to study
\vspace*{-2mm}

- Online scheduling heuristics
- Energy/temperature management
- Use of Machine Learning in scheduling
- Big data / HPC convergence (best effort Spark jobs within HPC cluster) \
  with distributed file system (HDFS)
- Evolving jobs with parallel file system + burst buffers
- Impact of user behaviors
- Fault tolerance

``` {=latex}
\end{frame}
\section{Coarse-grained simulation}
\begin{frame}{Table of Contents}
  \tableofcontents[currentsection,hideallsubsections]
```

### Profile evaluation from Batsim initial paper \footfullcite{batsim2015}
```{=latex}
\vspace*{-5mm}
```
Experiment

- Execute workloads with Batsim and on Grid'5000 (OAR)
- Same scheduler implementation (conservative backfilling)
- 9 synthetic workloads (4h each)
- Apps from NAS Parallel Benchmarks (IS, FT, LU), various sizes/classes
- Job profiles generated from app instrumentation
- Compare Gantt charts & scheduling objectives

Conclusions

- Real $\approx$ simulated for all profiles (delay, ptask, MPI replay)
- **Observed no interference** (network capacity > workload needs)


### Performance per profile type (2 synthetic workloads)
```{=latex}
  \centering
  \includegraphics[width=0.9\textwidth]{adrien/defense_simulation_time_comparison_with_zoom.pdf}
  \blfootnote{Reproduce repo. \url{https://gitlab.inria.fr/adfaure/ptask_tit_eval}}
```

### Profile types comparison

```{=latex}
  \centering
  \textbf{What performance/accuracy trade-off?}
  \vspace{2mm}
  \begin{columns}
    \begin{column}{0.3\textwidth}
      \begin{block}{Rigid delay}
        \begin{itemize}
          \item Very fast
          \item Context-free
          \item Rarely useful for apps \\(dynamic injection)
        \end{itemize}
      \end{block}
    \end{column}
    \begin{column}{0.39\textwidth}
      \vspace*{-1.5mm}
      \only<1-2>{
        \begin{block}{Parallel task}
      }
      \only<3>{
        \begin{alertblock}{Parallel task}
      }
        \begin{itemize}
          \item Fast enough!
          \item Coarse-grained interf.
          \item Versatile \& convenient
          \item Not validated yet
        \end{itemize}
      \only<1-2>{
        \end{block}
      }
      \only<3>{
        \end{alertblock}
      }
    \end{column}
    \begin{column}{0.3\textwidth}
      \vspace*{5mm}
      \only<1,3>{
        \begin{block}{MPI trace replay}
      }
      \only<2>{
        \begin{exampleblock}{MPI trace replay}
      }
        \begin{itemize}
          \item Much slower
          \item Fine-grained interf.
          \item MPI only
          \item Validated predictions \cite{simgridtit2015}
        \end{itemize}
      \only<1,3>{
        \end{block}
      }
      \only<2>{
        \end{exampleblock}
      }
    \end{column}
  \end{columns}
  \vspace{10mm}
  \begin{itemize}
    \item<2-> Agregate MPI traces $\rightarrow$ huge accuracy drop, almost no performance gain :(
    \item<3-> \textbf{Parallel tasks' accuracy needs to be evaluted}
  \end{itemize}
\end{frame}
```


### Evaluate parallel tasks — platform setup

```{=latex}
\only<1>{
  \textbf{\large Platform network\\}
  \vspace{1em}
  \centering
  \includegraphics[width=0.9\textwidth]{adrien/ptask_network_setup.pdf}
}\only<2>{
  \textbf{\large Reconfigured network\\}
  \vspace{1em}
  \centering
  \includegraphics[width=0.9\textwidth]{adrien/ptask_logical_network_setup.pdf}
}

\begin{columns}
  \begin{column}{0.6\textwidth}
  \begin{block}{Overdimensioned network}
    \textbf{Need to create a contention point!}
    \begin{itemize}
      \item Split switch into two groups (subnets)
      \item Inter-group comms via routing node
    \end{itemize}
  \end{block}
  \end{column}
  \begin{column}{0.4\textwidth}
    \textbf{Grid'5000 platforms}
      \begin{itemize}
        \item \textbf{Grisou} and \textbf{Paravance}
        \item Same homogeneous machines
        \item Different switch
      \end{itemize}
  \end{column}
\end{columns}
```

### Evaluate parallel tasks — application and noise

```{=latex}
\begin{columns}
  \begin{column}{0.5\textwidth}
    \\ \vspace{0.3em}
    \textbf{Real application (matrix multiplication)} 
    \begin{itemize}
      \item Matches parallel tasks hypotheses
        \begin{itemize}
          \item Short compute \& comm phases
          \item $\rightarrow$ Homogeneous progress
        \end{itemize}
      \item 8 nodes per group (16 core / node)
      \item Parameters
        \begin{itemize}
          \item Block size
          \item Sync / Async broadcasts
        \end{itemize}
    \end{itemize}
  \end{column}
  \begin{column}{0.5\textwidth}
    \textbf{Noise}
    \begin{itemize}
      \item High traffic generation via tcpkali
      \item 1 node per group
      \item Periodic ($T = 60~s$)
      \begin{itemize}
        \item $0~\%$ noise : $60~s$ idle
        \item $25~\%$ noise : $15~s$ traffic $\rightarrow$ $45~s$ idle
      \end{itemize}
    \end{itemize}
  \end{column}
\end{columns}
\vspace{1em}
\centering
\includegraphics[width=.9\textwidth]{adrien/ptask_logical_network_setup_interferences.pdf}
```

### Real runs behave as expected

```{=latex}
\center
\includegraphics[width=.7\textwidth]{adrien/paravance_ibcast_50sdiv_defense.pdf}
```

### Ptask vs Reality
```{=latex}
\vspace{2mm}
\begin{columns}
\begin{column}{0.45\textwidth}
  Results
  \begin{itemize}
    \item Parallel task: 0~\% point seems fine
    \item Parallel task: consistent behavior
    \item Real: Grisou \& Paravance are different
  \end{itemize}

  \vspace{3mm}
  Questions
  \begin{itemize}
    \item How to calibrate the 100~\% point?
    \item Why do Grisou \& Paravance switches' behavior differs so much?
  \end{itemize}
\end{column}
\begin{column}{0.52\textwidth}
  \begin{center}
    \includegraphics[width=.9\textwidth]{adrien/ptask_comparison.pdf}
  \end{center}
\end{column}
\end{columns}
\vspace{5mm}
```

$\rightarrow$ **Run another experiment with a more complex noise**
\vspace*{-2mm}

- Noise always active
- 5 nodes per group for the noise
- Many ways to connect noisy nodes together (random graph generation)

### Runtime vs Number of connections (real)

```{=latex}
\includegraphics[width=\textwidth]{adrien/datamovett_nb_connections.pdf}
```

### Runtime vs Number of pairs (real)

```{=latex}
\includegraphics[width=\textwidth]{adrien/datamovett_nb_pair.pdf}
```

### Grisou/Paravance difference explained
Grisou
\vspace*{-2mm}

- App performance correlated with number of TCP connections in noise
- Noise connection location has no effect

\vspace{5mm}
Paravance
\vspace*{-2mm}

- App performance correlated with number of different pairs of hosts in noise

\vspace{5mm}
#### Conclusions
- Switches have a different sharing policy
- SimGrid: Fair sharing among TCP connections regardless of their source/destination
- $\rightarrow$ \textbf{Ignore Paravance for now}

### Ptask vs Grisou — varying number of connections in noise
```{=latex}
\only<1>{
  \includegraphics[width=\textwidth]{adrien/ptask-vs-grisou-fullscreen.pdf}
}
\only<2>{
\begin{columns}
\begin{column}{0.45\textwidth}
  \vspace{2mm}
  \begin{center}
    \includegraphics[width=\textwidth]{adrien/ptask-vs-grisou.pdf}
  \end{center}
\end{column}
\begin{column}{0.52\textwidth}
  \begin{alertblock}{Houston, we have a problem!}
    \begin{itemize}
      \item \textbf{Huge} overestimation when link saturated by many connections
      \item Number of connections inside ptasks \textbf{ignored} by \texttt{ptask\_L07}
      \begin{itemize}
        \item Bad sharing when Big vs Small ptasks 
        \item No fix in \texttt{ptask\_L07} \\(recursive Max-Min Fairness)
      \end{itemize}
    \end{itemize}
    \vspace{5mm}
    $\rightarrow$ \textbf{New model implementation}
    \begin{itemize}
      \item Bottleck Max Fairness~\cite{bmf2015}
    \end{itemize}
  \end{alertblock}
\end{column}
\end{columns}
}
```

### Ptask-**BMF** vs Grisou — varying number of connections in noise
```{=latex}
\includegraphics[width=\textwidth]{adrien/ptask-bmf-vs-grisou.pdf}
```

# Conclusion
### Take home message
This talk in a nutshell
\vspace*{-2mm}

- SimGrid: sound toolkit to build your simulator
- Batsim: study resource management, tunable profile granularity
- `ptask_bmf`: very promising coarse-grained model

\vspace*{2mm}
Many questions around `ptask_bmf`
\vspace*{-2mm}

- BMF solution: existence but no uniqueness...
- Termination of fast/greedy solvers?
- Performance overhead?

\vspace*{2mm}
Batsim
\vspace*{-2mm}

- Validation of **applications** models?
- Ongoing architecture overhaul
  - Single-process simulations
  - Flatbuffers serialization

``` {=latex}
\end{frame}
\appendix
\begin{frame}<0| handout:0>
```

### Max-min Fairness
```{=latex}
\begin{overlayarea}{\linewidth}{0mm}\vspace{-5mm}\flushright{\includegraphics[height=2cm]{arnaud/max_min.pdf}}\end{overlayarea}

The $\min$ function is not strictly increasing so \\
a recursive optimization is needed
```

- Water-filling \cite{bertsekas:1987} 
  - Allocate $\epsilon$ to each flow until a link is saturated  $(\sum_i A_{i,j} \epsilon = C_j)\hspace{-1cm}$
  - Fix the saturated flows and repeat
- Recursive bottleneck identification  
  - For each link $j$, $\epsilon_j = C_j / \sum A_{i,j}$, consider $\epsilon=\min_j \epsilon_j$
  - Fix the saturated flows, update link capacity, and repeat

Low complexity, gracefully extends to weighted version, exploits the fact that $A_{i,j}\geq0$

```{=latex}
\blfootnote{\footnotesize Slide from Arnaud Legrand. \url{https://gitlab.inria.fr/alegrand/slides_fair_sharing}}
```

### Bottleneck Max Fairness

```{=latex}
max-min fairness $\sim$ "bottleneck resources are fairly shared"
```

- **Axiom** : Every "flow" $f$ has a bottleneck resource $j$ s.t.
  - $\sum_{i} A_{i,j}\rho_i = C_j$ \hfill (the resource is saturated)
  - $A_{f,j}\rho_f = \max_i A_{i,j}\rho_j$ \hfill ($f$ is active all the time)
    - $\leadsto$ Flows with the *same bottleneck* get the *same share*
  - Find $|\mathcal{F}|$ bottlenecks and solve $A'\rho=C'$

It is quite a reasonable choice for *streaming* and *parallel tasks*

```{=latex}
\blfootnote{\footnotesize Slide from Arnaud Legrand. \url{https://gitlab.inria.fr/alegrand/slides_fair_sharing}}
```

### References {.allowframebreaks}
```{=latex}
\printbibliography[heading=none]
```
