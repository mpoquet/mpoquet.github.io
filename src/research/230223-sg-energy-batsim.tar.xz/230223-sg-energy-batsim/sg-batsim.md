---
title: SimGrid and Batsim Overview
date: \vspace*{-8mm} 2023-02-23 \newline\newline ![](fig/sepia.png){height=1cm} \hspace{2mm} ![](fig/irit.png){height=1cm} \hspace{2mm} ![](fig/logo-ut3.png){height=1cm} \newline\newline ![](fig/logo-batsim.png){height=1cm} \hspace{2mm} ![](fig/logo-simgrid.png){height=1cm} \newline\newline ![](fig/energumen.png){height=1cm} \hspace{2mm} ![](fig/logo-regale.png){height=1cm}
author: Millian Poquet
theme: Estonia
#date: 2023-02-23
lang: en
classoption:
- aspectratio=169
header-includes:
- |
  ```{=latex}
  \usepackage{subcaption}
  \setbeamertemplate{footline}[frame number]
  \renewcommand\dots{\ifmmode\ldots\else\makebox[1em][c]{.\hfil.\hfil.}\thinspace\fi}
  \hypersetup{colorlinks,linkcolor=,urlcolor=estonian-blue}
  \graphicspath{{./fig/},{./img/}}

  % Fix pandoc shenanigans
  \setbeamertemplate{section page}{}
  \setbeamertemplate{subsection page}{}
  \AtBeginSection{}
  \AtBeginSubsection{}
  ```
---

# Introduction
### Study distributed systems and applications
Many distributed systems in use today (**HPC**, Clouds...) and tomorrow (Edge, Fog?)

Complex platforms with many issues (**energy**, fault tolerance, **scheduling**, scalability, heterogeneity...)

Methodological approaches

- Direct experimentation (real applications on real platforms)
- Simulation (application models on platforms models)
- Something in between (emulation, partial simulation...)

### Building simulators from scratch is risky

How useful is a simulator whose results cannot be trusted?

- Models validated?
- Implementation tested?
- Model instantiation evaluated?

**Doing it thoroughly may take (dozens of) years!**

\vspace{5mm}
Using SimGrid (or any validated simulation frameworks) helps a lot

- Thoroughly validated models
- Thoroughly tested implementation
- Model instantiation responsibility is still on you

# SimGrid
### Overview
Simulation framework around distributed platforms and applications

\vspace{2mm}
Main use cases

- Develop digital twins of distributed applications
- Evaluate various platform topologies/configurations
- Prototype systems or algorithms

\vspace{2mm}
Key features

- Sound/accurate models: theoretically and experimentally evaluated
- Scalable: fast models and implementations
- Usable: LGPL, linux/mac/windows, C++ Python and Java

### Overview (2)
Numbers

- Exists since early 2001, development still very active
- $\approx$ 200k lines of C/C++ code
- $\approx$ 35k commits
- Used in 500+ scientific articles

Community

- 4 main developers
- Many power users (current/previous PhD. students...)
- Get help easily (documentation, mailing list, irc, mattermost...)

### Architecture

How to build your simulator?

- Use one of the SimGrid interfaces
- Link the SimGrid library with your code

\vspace{5mm}
Available interfaces

- SMPI: `smpicc`/`smpirun` on your real MPI code
- S4U: write your own simulator (actors, messages), C++ C or Python
- MSG: older brother of S4U, C or Java
- MC: verify properties on your application *model* (model is code)

## Models
### Platform and network models
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  Platform = graph of hosts and links

  \vspace{3mm}
  Hosts : computational resources
  \begin{itemize}
    \item Speed (FLOP per second)
  \end{itemize}

  \vspace{3mm}
  Links : network resources (cables, switches, routers...)
  \begin{itemize}
    \item Latency (seconds)
    \item Bandwidth (bytes per second)
  \end{itemize}

  \vspace{3mm}
  Several network models available
  \begin{itemize}
    \item Fast flow-level: slow start, TCP congestion, cross-traffic
    \item Constant time: a bit faster (unrealistic)
    \item Packet-level: NS-3 binding
  \end{itemize}
\end{column}
\begin{column}{0.52\textwidth}
  \vspace{20mm}
  \includegraphics[width=\textwidth]{platform.pdf}
\end{column}
\end{columns}
```

### Actors, computations and communications
Actors

- One of the simulation \textit{actors} — AKA agent, thread, process...
- Executes user-given code on a Host
- User-given code may contain SimGrid calls

\vspace{5mm}
Main SimGrid calls

- Compute $x$ flops on current host
- Send $x$ bytes to an actor/host/mailbox
- Yield (just interrupt control flow)

### S4U simulator example (Python)

```{=latex}
{\footnotesize
```

~~~~ {#mycode .py}
from simgrid import Actor, Engine, Host, this_actor

def sleeper():
    this_actor.info("Sleeper started")
    this_actor.sleep_for(1)
    this_actor.info("I'm done. See you!")

def master():
    this_actor.execute(64)
    actor = Actor.create("sleeper", Host.current(), sleeper)
    this_actor.info("Join sleeper (timeout 2)")
    actor.join(2)

if __name__ == '__main__':
    e = Engine(sys.argv)
    e.load_platform(sys.argv[1])
    Actor.create("master", Host.by_name("Tremblay"), master)
    e.run()
~~~~~~~~~~~~~~~~~~~~~~~

```{=latex}
}
```

### Actor execution model
```{=latex}
\begin{columns}
\begin{column}{0.39\textwidth}
  Main points
  \begin{itemize}
    \item mutual exclusion on actors
    \item \textit{maestro} dictates who run
          (deterministic)
    \item SG calls $\approx$ syscalls
    \begin{itemize}
      \item interruption points inside user-given functions
    \end{itemize}
  \end{itemize}

  \vspace{7mm}
  Various implementations
  \begin{itemize}
    \item pthread: \textit{easy} debug, slow
    \item asm: blazing fast
    \item ucontext, boost context...
  \end{itemize}
\end{column}
\begin{column}{0.6\textwidth}
  \vspace{10mm}
  \includegraphics[width=\textwidth]{sg-kernel-actors.pdf}
\end{column}
\end{columns}
```

### Energy model (DVFS)
- Modern CPUs can reduce computation speed to save energy
- Power states: levels of performance. *Governors* pick them
- SimGrid: Manually switch pstates, which change the flop rate
- For each pstate, power consumption is a linear function of CPU use

```{=latex}
\centering
\vspace*{-1mm}
\includegraphics[width=0.67\textwidth]{cost-model-xkcd.pdf}
```

### Energy model (ON/OFF)

ON $\leftrightarrow$ OFF takes time (seconds) and energy (Joules)

```{=latex}
\begin{center}
    \includegraphics[width=.8\linewidth]{power-states-graph.pdf}
\end{center}
```

- Not easy for the noise:
  everybody wants something specific
- SimGrid provides basic mechanisms,
  you have to help yourself
- Switching ON/OFF is instantaneous

### Real usage example: StarPU's digital twin
StarPU
```{=latex}
\nointerlineskip
```

- Task programming library/runtime for hybrid architectures
- Input: graph of tasks (using StarPU library or OpenMP)
- Input: CPU/GPU/both implementation for each task
- Executes your application with optimized scheduling

How to do this digital twin?
```{=latex}
\nointerlineskip
```

- Copy/paste StarPU's code
- Use SimGrid actors and computations/communications calls \
  (working prototype within a few days)
- (Do some optimizations — e.g., replace real code by performance models)

How is it used?
```{=latex}
\nointerlineskip
```

- Test/tune performance of scheduling algo/parameters on many simulated platforms
- Scalability tests at low energy footprint

# Batsim
### Overview
Resource management simulator built on top of SimGrid

Main use cases

- Analyze and compare online scheduling algorithms
- Workload/platform dimensioning

Key features

- Prototype scheduling algorithms in any programming language
- Or use real schedulers (done on OAR and K8s, prototypes for flux/slurm)
- Several job models (tunable level of realism) without deep SimGrid knowledge

### Overview (2)
Numbers

- Exists since 2015
- $\approx$ 9k lines of C++ code
- $\approx$ 2k commits

Community

- 1-2 main developers at the same time
- Mostly used by PhD. students/interns from scientific labs so far
- Get help easily (documentation, mailing list, mattermost)

### Architecture
```{=latex}
\begin{center}
\includegraphics[height=.9\textheight]{batsim-rjms-overview.pdf}
\end{center}
```

<!-- ### Architecture (2)
```{=latex}
\begin{center}
\includegraphics[height=.9\textheight]{batsim-archi3d.pdf}
\end{center}
``` -->

### Protocol
```{=latex}
\begin{columns}
\begin{column}{0.55\textwidth}
  \includegraphics[width=\textwidth]{batproto-request-reply.pdf}
\end{column}
\begin{column}{0.4\textwidth}
  Classical scheduling events
  \begin{itemize}
    \item Job submitted
    \item Job finished
  \end{itemize}

  \vspace{3mm}
  Resource management decisions
  \begin{itemize}
    \item Execute job $j$ on $M = \{ 1, 2 \}$
    \item Shutdown $M = \{3, ..., 5\}$
  \end{itemize}

  \vspace{3mm}
  Simulation/monitoring control
  \begin{itemize}
    \item Call scheduler at $t=120$
    \item How much energy used?
    \item How much data moved?
  \end{itemize}

\end{column}
\end{columns}
```

## Models
### Platform
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  SimGrid platform + some sugar

  \vspace{7mm}
  RJMS internals on \textit{master} host

  \vspace{7mm}
  Disks modeled as speed=0 hosts
  \begin{itemize}
    \item Enables parallel task use
  \end{itemize}
\end{column}
\begin{column}{0.52\textwidth}
  \vspace{7mm}
  \includegraphics[width=\textwidth]{platform-io.pdf}
\end{column}
\end{columns}
```

### Shutdown model
```{=latex}
Batsim implements a DVFS and simple shutdown model on top of SimGrid's instantaneous power states (pstates).
\begin{itemize}
  \setlength\itemsep{-1mm}
  \nointerlineskip
  \item \textbf{Computation} pstates: DVFS states
  \item \textbf{Sleep} pstates: cannot compute anything -- \textit{e.g.}, ACPI S1, S3, S4 or S5
  \item \textbf{Transition} (virtual) pstates: used internally to simulate the transition into/from sleep pstates
\end{itemize}

\vspace{3mm}
Transition costs can be set for each host, for each pair of pstates.
\begin{itemize}
  \setlength\itemsep{-1mm}
  \nointerlineskip
  \item computation $\rightarrow$ computation: 0
  \item computation $\rightarrow$ sleep: fixed amount of time and energy (shutdown)
  \item sleep $\rightarrow$ computation: fixed amount of time and energy (boot=)
  \item sleep $\rightarrow$ sleep: forbidden, use an intermediate computation pstate
\end{itemize}

```

### Jobs and profiles
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  Jobs : scheduler view
  \begin{itemize}
    \item User resource request
    \item (Walltime)
    \item Simulation profile
  \end{itemize}

  \vspace{3mm}
  Profiles : simulator view
  \begin{itemize}
    \item How to simulate the app?
  \end{itemize}

  \vspace{3mm}
  Profile types
  \begin{itemize}
    \item Fixed length
    \item Parallel task
    \item MPI trace replay
    \item Sequence
    \item Convenient shortcuts
    \begin{itemize}
      \item IO transfers (alone)
      \item IO transfers (along- task)
    \end{itemize}
  \end{itemize}
\end{column}
\begin{column}{0.52\textwidth}
  %\vspace{7mm}
  \includegraphics[width=.95\textwidth]{ptask-and-sequence.pdf}
\end{column}
\end{columns}
```

### Application model example: Stencil with checkpoints
```{=latex}
\begin{columns}
\begin{column}{0.45\textwidth}
  \begin{enumerate}
    \item Loads data from parallel filesystem
    \item Iteration: local computations, exchange data with neighbors
    \item Every 100 iterations: dump checkpoint on parallel file system
    \item Stop after 1000 iterations.
  \end{enumerate}

  \vspace{3mm}
  \begin{center}
    \includegraphics[width=.5\textwidth]{stencil-ranks.pdf}
  \end{center}
\end{column}
\begin{column}{0.52\textwidth}
  Profile example
  \begin{itemize}
    \item Bundle 100 iterations in 1 parallel task
  \end{itemize}
  \vspace{5mm}
  \begin{center}
    \includegraphics[width=.6\textwidth]{stencil-profiles.pdf}
  \end{center}
\end{column}
\end{columns}
```

### Application model example: Stencil with checkpoints (code)

```{=latex}
{\tiny
```

~~~ {#mycode .json}
{ "initial_load": {
    "type": "parallel_homogeneous_pfs",
    "bytes_to_read": 67108864,
    "bytes_to_write": 0,
    "storage": "pfs" },
  "100_iterations": {
    "type": "parallel",
    "cpu": [   1e9,    1e9,    1e9,    1e9],
    "com": [     0, 819200, 819200,      0,
            819200,      0,      0, 819200,
            819200,      0,      0, 819200,
                 0, 819200, 819200,      0] },
  "checkpoint": {
    "type": "parallel_homogeneous_pfs",
    "bytes_to_read": 0,
    "bytes_to_write": 67108864,
    "storage": "pfs" },
  "iterations_and_checkpoints": {
    "type": "composed",
    "repeat": 10,
    "seq": ["100_iterations", "checkpoint"] },
  "imaginary_stencil": {
    "type": "composed",
    "repeat": 1,
    "seq": ["initial_load", "iterations_and_checkpoints"] }
}
~~~

```{=latex}
}
```

## Ecosystem and Usage
### Ecosystem and Usage
Ecosystem

- Set of scheduling algorithms (C++, Python, Rust, D, Perl...)
- Tools to generate platforms and workloads
- (Interactive) tools to visualize/analyze Batsim results
- Tools to help experiments (environment control, execution...)

Already used to study

- Energy/temperature related scheduling heuristics
- Big data / HPC convergence (best effort Spark jobs within HPC cluster) \
  with distributed file system (HDFS)
- Evolving jobs with parallel file system + burst buffers

# Conclusion
### Conclusion
Take home message

- Simulation is a precious tool to study distributed systems/applications
- SimGrid: 20 years of model (in)validation and optimizations
- Give SimGrid a try, it may save you a lot of time
- Batsim: Specialized SimGrid use around resource management

\vspace{6mm}
Thanks! :)

- `millian.poquet@irit.fr`
- `https://framateam.org/simgrid/channels/town-square`
- `https://framateam.org/batsim/channels/town-square`
