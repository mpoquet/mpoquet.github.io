#import "@preview/minideck:0.2.1"
#import "estonia.typ": variants, estonia
#import "@preview/timeliney:0.0.1"
#import "@preview/cetz:0.2.2"
#import "@preview/fletcher:0.5.1" as fletcher: diagram, node, edge

#let (template, slide, title-slide, pause, uncover, only) = minideck.config(
  paper: "16:9",
  theme: estonia
)
#let variant = "batsim"
#let vcol = variants.at(variant)
#show: template.with(variant: variant)

#let focus-slide(it, variant: variant) = {
  set page(fill: variants.at(variant).title-bg)
  set text(fill: variants.at(variant).title-fg)
  title-slide(it)
}

#let rimage(f, ..args) = image.decode(
  read(f)
  .replace("Liberation Sans", "Fira Sans")
  .replace("spacingAndGlyphs", "spacing"),
  ..args
)

#let col(body) = strong(text(fill: vcol.title-bg, body))

#title-slide[#{
  set align(left)
  show: pad.with(2em)
  grid(columns: 1, row-gutter: 1fr,
    {
      text(size: 1.3em, strong[Me, Myself and I --- Overview of my research activities\ ])
      text(size: .8em)[with some questions and frustrations on experimentation]
      v(-2mm)
      line(length: 100%, stroke: .2em + black)
    },
    grid(columns: (auto, 40%), column-gutter: 1fr,
      [
        Millian #smallcaps([Poquet]) \
        #link("mailto:millian.poquet@irit.fr")\

        #v(7mm)
        2024-12-13, IRIT scientific day
      ],
      //pad(1.5cm, align(center+horizon, image(width: 100%, "fig/logo-batsim.svg"))),
    ),
    align(center, grid(columns: (1fr, 1fr, 1fr), gutter: 0cm,
      [ #image(fit: "contain", height: 3cm, "fig/logo-ut3.svg") ],
      [ #image(fit: "contain", height: 2.5cm, "fig/logo-irit.svg") ],
      [ #image(fit: "contain", height: 2cm, "fig/logo-sepia.svg") ],
    ))
  )
}]

#slide[
  == Maître de conférences since 2022-09

  Teaching at Univ. Toulouse III, FSI
  - System programming & design: L1 $->$ M2
  - Parallel computing: L3 $->$ M1

  #v(1cm)
  Research at IRIT
  - SEPIA team, ASR department
  - UT3 site, IRIT2-469
  - Missions: ecological transition, egality parity
  - Grid'5000 group manager
]

#slide[
  == This short talk's content
  + Give an overview of things I work(ed) on
  + #strike[Good practice about experimentation] #text(size: .5em)[_(Ain't Nobody Got Time for That)_]
  + Future directions
]

#slide[
  == Secondary school
  #grid(
    columns: (auto, 8cm),
    column-gutter: 5cm,
    [
      Learn how to program!
      - _Worms Armageddon_ map editor
      - _Ultima Online_ mining bot
    ],
    image("./fig/siteduzero.jpg")
  )

  #grid(
    columns: (10cm, 10cm),
    column-gutter: 4.5cm,
    image("./fig/wa-rr.png"),
    image("./fig/uo-mine.jpg"),
  )
]

#slide[
  == Master TER work at Orléans --- Modulight
  #v(-5mm)
  Middleware to couple $parallel$ simulator with $parallel$ visualization and user interaction

  #set align(center)
  #grid(
    columns: (40%, 50%),
    column-gutter: 2cm,
    image("./fig/fvnano-pieuvre.png", width: 90%),
    image("./fig/fvnano-schema.png", width: 90%),
  )

  #set align(bottom+right)
  #set text(size: 0.8em)
  #grid(
    columns: (4cm, 4cm),
    column-gutter: 1cm,
    [
      #image("./fig/slimet.jpg", width: 3cm)
      #v(-5mm)
      S. Limet
    ],
    [
      #image("./fig/srobert.jpg", width: 3cm)
      #v(-5mm)
      S. Robert
    ],
  )
]

#slide[
  == PhD work at Grenoble --- Batsim
  #v(-5mm)
  #grid(
    columns: (76%, 16%),
    column-gutter: 1fr,
    {
      only(1, image("./fig/batsim-rjms-overview-real-only.svg", width: 100%))
      only(2, image("./fig/batsim-rjms-overview.svg", width: 100%))
    },
    [
      #set align(right)
      #set text(size: 0.6em)
      #image("./fig/aussois24.jpg", width:100%)
      #v(-3mm)
      PF Dutot, D. Trystram

      #v(5mm)
      #image("./fig/orichard.jpg", width:40%)
      #v(-3mm)
      O. Richard

      #v(5mm)
      #image("./fig/mmercier.jpg", width:70%)
      #v(-3mm)
      M. Mercier
    ]
  )
]

#slide[
  == Postdoc work at Grenoble --- NixOS Compose
  #grid(
    columns: (35%, 60%),
    column-gutter: 1fr,
    image("./fig/nxc-overview.svg", width: 100%),
    only(2, image("./fig/nxc-workflow.png", width: 100%)),
  )

  #v(-5mm)
  #set align(bottom+right)
  #set text(size: 0.6em)
  #grid(
    columns: (4cm, 4cm, 4cm),
    column-gutter: 1cm,
    [
      #image("./fig/qguilloteau.jpg", width: 3cm)
      Q. Guilloteau
    ],
    [
      #image("./fig/jbleuzen.jpg", width: 3cm)
      J. Bleuzen
    ],
    [
      #image("./fig/orichard.jpg", width: 2cm)
      O. Richard
    ]
  )
]

#slide[
  == MCF work at Toulouse --- Artifacts State of the Practice
  #v(-5mm)
  #only(1, 2, grid(
    columns: (48%, 48%),
    column-gutter: 1fr,
    only(1, 2, image("./fig/rep24-fig-1.png", width: 100%)),
    only(2, image("./fig/rep24-fig-2.png", width: 90%)),
  ))
  #only(3, align(center, image("./fig/rep24-fig-3.png", width: 60%)))

  #v(-5mm)
  #set align(bottom+right)
  #set text(size: 0.6em)
  #grid(
    columns: (4cm, 4cm, 4cm, 4cm),
    column-gutter: 1cm,
    [
      #image("./fig/qguilloteau.jpg", width: 3cm)
      Q. Guilloteau
    ],
    [
      #image("./fig/fmciorba.jpg", width: 3cm)
      F. M Ciorba
    ],
    [
      #image("./fig/anonymous.svg", width: 2cm)
      D. Goepp
    ],
    [
      #image("./fig/orichard.jpg", width: 2cm)
      O. Richard
    ]
  )
]

#slide[
  == Future directions
  Tools for REP experimentation
  - Good tools already exist --- _e.g._, SimGrid 2001, Nix 2003, G5K 2003, SH 2016
    - Invest into them --- SG models, Nix accessibility, G5K features...
  - New tools needed? Binary REP, well-designed workflow engine...

  #v(1cm)
  _Ethics_ and experimentation
  - #strike[Computer] Scientific Method when? [Patterson 2001]
  - Environmental footprint of experiments considered when?
  - What accessibility/quality tradeoffs?
]
