Reproduce
=========

``nix develop .#typst-shell --command typst watch mpoquet-expe.typ``
