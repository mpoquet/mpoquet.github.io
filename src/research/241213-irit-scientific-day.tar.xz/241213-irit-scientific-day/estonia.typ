#let variants = (
  estonia: (
    page-bg: white,
    title-bg: rgb("#0072ce"),
    title-fg: white,
    //text-fg: rgb("#3c3c3c"),
    text-fg: black,
  ),
  batsim: (
    page-bg: white,
    title-bg: rgb("f9de2d"),
    title-fg: black,
    //text-fg: rgb("#3c3c3c"),
    text-fg: black,
  ),
  irit: (
    page-bg: white,
    title-bg: rgb("d64000"),
    title-fg: white,
    //text-fg: rgb("#3c3c3c"),
    text-fg: black,
  ),
)

#let template(page-size: none, variant: none, margin: (x: 1cm, top: 3mm, bottom: 1cm), it) = {
  let v = variants.at(variant)
  show heading: it => [
    #set align(left+top)
    #set text(24pt, weight: "regular", fill: v.title-fg)
    #pad(left: -margin.x, top: -margin.top,
      block(width: page-size.width, height: auto, fill: v.title-bg,
        pad(x: margin.x, top: margin.top, bottom: margin.top,
          grid(columns: 2, column-gutter: 1fr,
            it.body,
            grid(columns: (auto, 5mm), column-gutter: 5mm,
              align(bottom+right, text(size:.5em)[Millian #smallcaps[Poquet]]),
              counter(page).display()
            )
          )
        )
      )
    )
  ]
  show raw: set text(font: "Inconsolata", weight: "semibold", size: 1.1em)
  show link: v => underline(text(v, font: "Inconsolata", weight: "semibold", size: 1.0em, fill: variants.at("estonia").title-bg))
  show math.equation: set text(font: "Fira Math", weight: "regular")
  set page(
    width: page-size.width,
    height: page-size.height,
    margin: margin,
    header-ascent: 0pt,
    footer-descent: 0pt,
    fill: v.page-bg,
    footer: [],
  )
  set text(20pt, font: "Fira Sans", fill: v.text-fg)
  set align(left+horizon)
  set image(width: 100%)
  set par(justify: true)
  it
}

#let title-slide(slide, it) = {
  set page(footer: none)
  show heading: it => [
    #block(it.body)
  ]
  set align(horizon+center)
  slide(it)
}

#let estonia(slide, page-size: none, variant: "estonia") = {
  (
    slide: slide,
    title-slide: title-slide.with(slide),
    template: template.with(page-size: page-size, variant: variant),
  )
}
