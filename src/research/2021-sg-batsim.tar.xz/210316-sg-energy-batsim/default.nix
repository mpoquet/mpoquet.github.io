{ pkgs ? import (fetchTarball "https://github.com/NixOS/nixpkgs/archive/20.03.tar.gz") {}
}:

let
  jobs = rec {
    inherit pkgs;

    slides = pkgs.stdenv.mkDerivation {
      pname = "git-slides";
      version = "0.1.0";
      nativeBuildInputs = with pkgs; [
        texlive.combined.scheme-full
        pandoc
        ninja
        inkscape
        asymptote
      ] ++ r-shell.buildInputs;
      src = pkgs.lib.sourceByRegex ./. [
        "^build\.ninja$"
        "^slides$"
        "^fig"
        "^fig/.*\.svg"
        "^fig/power-states-graph\.pdf"
        "^fig/cost-model-xkcd\.pdf"
        "^.*\.md$"
        "^.*\.sty$"
      ];
      buildPhase = ''
        ninja
      '';
      installPhase = ''
        mkdir -p $out
        mv sg-batsim.pdf $out/
      '';
    };

    autorebuild-shell = pkgs.mkShell rec {
      name = "autobuild-shell";
      buildInputs = [
        pkgs.entr
      ] ++ slides.nativeBuildInputs;
      shellHook = ''
        ls build.ninja *.md *.sty fig/*.svg | entr -s "ninja ; killall -HUP --regexp '(.*bin/)?llpp'"
      '';
    };

    r-shell = pkgs.mkShell rec {
      name = "r-shell";
      buildInputs = [
        pkgs.R
        pkgs.rPackages.docopt
        pkgs.rPackages.tidyverse
        pkgs.rPackages.timelineS
        pkgs.rPackages.viridis
      ];
    };
  };
in
  jobs
