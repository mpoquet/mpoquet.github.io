#import "@preview/touying:0.6.1": *
#import themes.metropolis: *
#import "@preview/cetz:0.4.0"
#import "@preview/showybox:2.0.4": showybox

#set par(justify: true)
#show link: v => underline(text(v, font: "DejaVu Sans Mono", weight: "regular", size: .8em, fill: blue))
#set raw(theme: "mpoquet.tmTheme")

#let metrocolor = rgb("#23373b")
#let def-box = showybox.with(frame: (title-color: metrocolor), title-style: (color: white, align: left))

// cetz and fletcher bindings for touying
#let cetz-canvas = touying-reducer.with(reduce: cetz.canvas, cover: cetz.draw.hide.with(bounds: true))
//#let fletcher-diagram = touying-reducer.with(reduce: fletcher.diagram, cover: fletcher.hide)

#show: metropolis-theme.with(
  aspect-ratio: "16-9",
  config-info(
    title: [Introduction to Nix],
    subtitle: [NixOS Compose tutorial, ComPAS'25, Bordeaux],
    author: [Millian #smallcaps[Poquet], Quentin #smallcaps[Guilloteau], Olivier #smallcaps[Richard]],
    date: [2025-06-24],
  ),
)

#let terminal(width: 100%, height: auto,
  fill: rgb("#282c34"), stroke: none,
  text-color: rgb("#ffffff"),
  pad-x: 2mm, pad-y: 2mm,
  content
) = {
  block(width: width, height: height, fill: fill, stroke: stroke, {
    show: pad.with(x: pad-x, y: pad-y)
    show raw: set text(fill: text-color)
    show regex("\$"): set text(fill: rgb("#f9de2d"))
    show regex("\(nix-shell\)"): set text(fill: rgb("#c678dd"))
    content
  })
}

#show strong: it => text(fill: luma(10%), it)

#title-slide()

== Nix's main idea
#slide[
  #def-box(title: [Definition])[
    An operation is said to have a *side effect* if it has any observable effect other than its primary effect of reading the value of its arguments and returning a value to the invoker of the operation.
  ]

  How to manage software *without* side effects ?
  - *Immutable* file system to store packages
  - *Pure* functions to build packages
  - *Cryptographic hashes* for external data (source code...)
]

== What is Nix?
#slide[
  #grid(
    columns: (auto, 7cm),
    column-gutter: 4cm,
    [
      *Nix*: package manager
      - Download, store and _install_ packages
      - Get into tmp well-defined environments (shells)\
        - `virtualenv`, but for any language\
        - `docker run`, but without isolation

      *Nix*: programming language
      - #sym.lambda DSL
      - Define how to build packages
      - Define environments (set of packages)

      *NixOS*: Linux distribution
      - Declarative system config via Nix language
      - Sources: https://github.com/NixOS/nixpkgs
    ],
    image("fig/nix-logo.svg", width: auto),
  )
]

== How to store packages?
#slide[
  #grid(
    columns: (1fr, 8cm),
    column-gutter: 2cm,
    [
      *Filesystem Hierarchy Standard*
      - All packages merged together
      - Multiversion is tedious
      - Always in the _default_ environment
        - ELFs with vague deps -- `require libmylib.so`
        - Libs from default paths (`/lib`, `/usr/lib`, or `ldconfig`)
        - PATH to default paths or hacked
    ],
    [
      #set align(right)
      #cetz-canvas({
        import cetz.draw: *
        let x = 1.1
        let xo = 0.2
        let y = -0.8
        let yo = 0.2
        content((0,0), anchor: "text", `/usr`)
        content((1*x,1*y), anchor: "text", `bin`)
        content((2*x,2*y), anchor: "text", `program`)
        content((1*x,3*y), anchor: "text", `lib`)
        content((2*x,4*y), anchor: "text", `libc.so`)
        content((2*x,5*y), anchor: "text", `libmylib.so`)

        line((xo,-yo), (xo,3*y + yo), (1*x - xo, 3*y + yo))
        line((xo,-yo), (xo,1*y + yo), (1*x - xo, 1*y + yo))
        line((1*x + xo, 1*y - yo), (1*x + xo, 2*y + yo), (2*x - xo, 2*y + yo))
        line((1*x + xo, 3*y - yo), (1*x + xo, 4*y + yo), (2*x - xo, 4*y + yo))
        line((1*x + xo, 3*y - yo), (1*x + xo, 5*y + yo), (2*x - xo, 5*y + yo))
      })
    ]
  )
]

== How to store packages?
#slide[
  *Nix Store*
  - Each package in its own directory + links
  - Naming: hash of inputs + package name + package "version"
  - Precise dependencies
    - ELFs have set `DT_RUNPATH`
    - Wrapper scripts to set `PATH`, `PYTHONPATH`...
  #v(6mm)
  #cetz-canvas({
    import cetz.draw: *
    let x = 1.1
    let xo = 0.2
    let y = -0.8
    let yo = 0.2
    content((0,0), anchor: "text", `/nix/store`)
    content((1*x,1*y), anchor: "text", `y9zg6ryffgc5c9y67fcmfdkyyiivjzpj-glibc-2.27`)
    content((2*x,2*y), anchor: "text", `lib`)
    content((3*x,3*y), anchor: "text", `libc.so`)
    content((1*x,4*y), anchor: "text", `nc5qbagm3wqfg2lv1gwj3r3bn88dpqr8-mypkg-0.1.0`)
    content((2*x,5*y), anchor: "text", `bin`)
    content((3*x,6*y), anchor: "text", `program`)
    content((2*x,7*y), anchor: "text", `lib`)
    content((3*x,8*y), anchor: "text", `libmylib.so`)

    line((xo,-yo), (xo,1*y + yo), (1*x - xo, 1*y + yo))
    line((xo,-yo), (xo,4*y + yo), (1*x - xo, 4*y + yo))
    line((1*x + xo, 1*y - yo), (1*x + xo, 2*y + yo), (2*x - xo, 2*y + yo))
    line((1*x + xo, 4*y - yo), (1*x + xo, 5*y + yo), (2*x - xo, 5*y + yo))
    line((1*x + xo, 4*y - yo), (1*x + xo, 7*y + yo), (2*x - xo, 7*y + yo))
    line((2*x + xo, 2*y - yo), (2*x + xo, 3*y + yo), (3*x - xo, 3*y + yo))
    line((2*x + xo, 5*y - yo), (2*x + xo, 6*y + yo), (3*x - xo, 6*y + yo))
    line((2*x + xo, 7*y - yo), (2*x + xo, 8*y + yo), (3*x - xo, 8*y + yo))

    set-style(mark: (end: ">", fill: black, scale: 2), stroke: black)
    bezier((6, 6*y + yo), (6, 3*y + yo), (30, 3*y))
    bezier((6, 6*y + yo - 0.1), (7.25, 8*y + yo), (15, 7*y))
  })
]

== How does Nix achieve purity?
#slide[
  *Main ideas*
  - Content hash used for external data (source code / bootstrap)
  - Packages are built in a sandbox (Linux namespaces)
    - Controlled builder args and env vars
    - No filesystem access outside of build script / sources / deps
    - No network/ipc/... access

  #grid(
    columns: (auto, 1fr),
    column-gutter: 2cm,
    [
      *Workflow to build a package*
      + Build all deps
      + Run build in sandbox
        - Input: build script (read-only)
        - Inputs: all deps paths (read-only)
        - Outputs: temp dirs
      + temp dirs $->$ Store (DB transaction)
    ],
    [
      #v(-5mm)
      #cetz-canvas({
        import cetz.draw: *
        let xbo = 0
        let x = 1.1
        let xo = 0.2
        let y = -0.8
        let yo = 0.2

        rect((-0.25,0.5), (6, -5.25), fill: luma(90%))
        content(((-0.25 + 6) / 2, -6.5), align(center)[Filesystem view\ from sandbox])

        content((xbo+0,0), anchor: "text", `/`)
        content((xbo+1*x,1*y), anchor: "text", `nix/store`)
        content((xbo+2*x,2*y), anchor: "text", `[a]-gcc`)
        content((xbo+2*x,3*y), anchor: "text", `[b]-mydep1`)
        content((xbo+2*x,4*y), anchor: "text", `[c]-mydep2`)
        content((xbo+1*x,5*y), anchor: "text", `build`)
        content((xbo+1*x,6*y), anchor: "text", `out`)

        line(                (xbo + xo,1*y + yo), (xbo + 1*x - xo, 1*y + yo))
        line(                (xbo + xo,5*y + yo), (xbo + 1*x - xo, 5*y + yo))
        line((xbo + xo,-yo), (xbo + xo,6*y + yo), (xbo + 1*x - xo, 6*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 2*y + yo), (xbo + 2*x - xo, 2*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 3*y + yo), (xbo + 2*x - xo, 3*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 4*y + yo), (xbo + 2*x - xo, 4*y + yo))

        xbo = 8
        content((xbo+0,0), anchor: "text", `/`)
        content((xbo+1*x,1*y), anchor: "text", `nix/store`)
        content((xbo+2*x,2*y), anchor: "text", `[a]-gcc`)
        content((xbo+2*x,3*y), anchor: "text", `[b]-mydep1`)
        content((xbo+2*x,4*y), anchor: "text", `[c]-mydep2`)
        content((xbo+2*x,5*y), anchor: "text", `...`)
        content((xbo+1*x,6*y), anchor: "text", `...`)
        content((xbo+1*x,7*y), anchor: "text", `tmp`)
        content((xbo+2*x,8*y), anchor: "text", `tmp.01`)
        content((xbo+2*x,9*y), anchor: "text", `tmp.02`)

        line(                (xbo + xo,1*y + yo), (xbo + 1*x - xo, 1*y + yo))
        line(                (xbo + xo,6*y + yo), (xbo + 1*x - xo, 6*y + yo))
        line((xbo + xo,-yo), (xbo + xo,7*y + yo), (xbo + 1*x - xo, 7*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 2*y + yo), (xbo + 2*x - xo, 2*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 3*y + yo), (xbo + 2*x - xo, 3*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 4*y + yo), (xbo + 2*x - xo, 4*y + yo))
        line((xbo + 1*x + xo, 1*y - yo), (xbo + 1*x + xo, 5*y + yo), (xbo + 2*x - xo, 5*y + yo))
        line((xbo + 1*x + xo, 7*y - yo), (xbo + 1*x + xo, 8*y + yo), (xbo + 2*x - xo, 8*y + yo))
        line((xbo + 1*x + xo, 7*y - yo), (xbo + 1*x + xo, 9*y + yo), (xbo + 2*x - xo, 9*y + yo))

        set-style(mark: (end: ">", fill: metrocolor, scale: 2.5), stroke: (paint: black))
        line((5, 2*y + yo), (9, 2*y + yo))
        line((5.75, 3*y + yo), (9, 3*y + yo))
        line((5.75, 4*y + yo), (9, 4*y + yo))
        line((3, 5*y + yo), (7.75, 5*y + yo), (7.75, 8*y + yo), (9, 8*y + yo))
        line((2.25, 6*y + yo), (6.5, 6*y + yo), (6.5, 9*y + yo), (9, 9*y + yo))
      })
    ],
  )
]

== Nix #sym.lambda example -- explicit hello world package
#slide[
  #grid(
    columns: (60%, 25%),
    column-gutter: 2.5cm,
    align: top,
    [
      #set text(size: .8em)
      #showybox(frame: (inset: (x: 0.25em, y: 0.5em)))[
        #let hello-nix-fn = read("./code/hello.nix")
        #raw(hello-nix-fn, lang: "nix")
      ]
    ],
    [
      Entry points
      + `prePhases`
      + `unpackPhase`
      + `patchPhase`
      + `(pre)configurePhase`
      + `(pre)buildPhase`
      + `checkPhase`
      + `(pre)installPhase`
      + ...
      + `postPhases`

      #v(5mm)
      Customized by
      - setting `phases`
      - using another builder
    ],
  )
]

== Nix #sym.lambda example -- real package, using a build system
#slide[
  #grid(
    columns: (1fr, 33%),
    column-gutter: 1cm,
    [
      #set text(size: .75em)
      #showybox(width: 100%, frame: (inset: (x: 0.5em, y: 0.5em)))[
        #let hello-nix-fn = read("./code/intervalset.nix")
        #raw(hello-nix-fn, lang: "nix")
      ]
    ],
    [
      Usual build layers
      - Package manager: `nix`, `apt`...
      - Build system: `meson`, `cmake`...
      - DAG builder: `ninja`, `make`...
      - Compiler: `clang`, `gcc`...
    ],
  )
]

== Package customization -- tune #sym.lambda args via `override`
#slide[
  #set text(size: .8em)
  #showybox(width:75%)[
    ```nix
    packages = rec {
      intervalset = pkgs.callPackage ./intervalset.nix { };
      intervalset-as-debian10 = intervalset.override {
        boost = boost-167;
        meson = meson-049;
      };

      boost-176 = ...;
      boost-167 = ...;
      boost = boost-176;

      meson-058 = ...;
      meson-049 = ...;
      meson = meson-058;
    };
    ```
  ]
]

== Package customization -- tune #sym.lambda definition via `overrideAttrs`
#slide[
  #set text(size: .8em)
  #showybox(width:75%)[
    ```nix
    packages = rec {
      intervalset = pkgs.callPackage ./intervalset.nix { };
      intervalset-110 = intervalset.overrideAttrs (old: rec {
        version = "1.1.0";
        src = pkgs.fetchgit {
          url = "https://framagit.org/batsim/intervalset.git";
          rev = "v${version}";
          hash = "sha256-auMx9J8h3nqNVB4qLcnxVRua4E3jy5bNc2e/REPOek4=";
        };
      });
      intervalset-local = intervalset.overrideAttrs (old: rec {
        version = "local";
        src = "/home/user/projects/intervalset";
        mesonBuildType = "debug";
      });
    };
    ```
  ]
]

== Nix code example -- shell
#slide[
  #set text(size: .75em)
  #grid(
    columns: (30%, 1fr),
    column-gutter: 5mm,
    align: top,
    [
      #showybox(frame: (inset: (x: 0.25em, y: 0.5em)))[
        #let hello-nix-fn = read("./code/shell.nix")
        #raw(hello-nix-fn, lang: "nix")
      ]
    ],
    [
      #terminal[
        ```
        $ sysbench --version
        sh: sysbench: command not found
        $ python --version
        sh: python: command not found

        $ nix-shell ...
        (nix-shell) $ sysbench --version
        sysbench 1.0.20
        (nix-shell) $ python --version
        Python 3.12.7
        (nix-shell) $ python
        Python 3.12.7 (main, Oct  1 2024, 02:05:46) [GCC 13.3.0] on linux
        Type "help", "copyright", "credits" or "license" for more information.
        >>> import numpy
        >>> numpy.__version__
        '1.26.4'
        >>> exit()
        ```
      ]
    ]
  )
]

== Nix code example -- container
#slide[
  #set text(size: .75em)
  #grid(
    columns: (46%, 50%),
    column-gutter: 1fr,
    align: top,
    def-box(title: text(size: 1.33em)[Big image])[
      ```nix
      packages = rec {
        hello = pkgs.callPackage ./hello.nix {};
        hello-cont = pkgs.dockerTools.buildImage {
          name = "hello";
          tag = "latest";
          created = "now";
          copyToRoot = pkgs.buildEnv {
            name = "image-root";
            paths = [ hello ];
            pathsToLink = [ "/bin" ];
          };
          config.Cmd = [ "/bin/hello" ];
        };
      };
      ```
    ],
    def-box(title: text(size: 1.33em)[2 layers])[
      ```nix
      { dockerTools, batsim, bash }:
      let self = rec {
        layer-dependencies = dockerTools.buildImage {
          name = "oarteam/batsim-deps";
          tag = batsim.version;
          copyToRoot = batsim.runtimeDeps ++ [ bash ];
        };
        layer-batsim = dockerTools.buildImage {
          fromImage = layer-dependencies;
          fromImageName = layer-dependencies.name;
          fromImageTag = layer-dependencies.tag;
          tag = layer-dependencies.tag;
          name = "oarteam/batsim";
          config = {
            # ...
          };
        };
      };
      in
        self.layer-batsim
      ```
    ],
  )
]

== Where to write your Nix expressions?
#slide[
  Evaluating remote (git, some https server...) Nix expressions is as easy as local ones (files)\
  $->$ You are free to decide where to write your Nix files

  #v(1cm)
  *Common locations*
  - Git repo of your software
  - Git repo of your experiment
  - Git repo of a set of tools you (or your team/lab/...) manage
  - Nixpkgs
]

== Nix limits
#slide[
  Reproducible builds only if
  - Compiler is deterministic
  - Build chain (build system...) is deterministic

  #v(-5mm)
  #def-box(title: [Quote from the Meson's doc])[
    _
    Meson aims to support reproducible builds out of the box with zero additional work (assuming the rest of the build environment is set up for reproducibility). If you ever find a case where this is not happening, it is a bug. Please file an issue with as much information as possible and we'll get it fixed.
    _
  ]

  Contaminant approach -- cannot reuse non-Nix packages
  - Nixpkgs has much more packages than any other Linux distro#footnote[https://repology.org/repositories/statistics #linebreak() #h(8mm) As of 2025-06-23, nixpkgs=106475, AUR=78079, debian12=34451]
  - Writing your own package is straightforward
]
