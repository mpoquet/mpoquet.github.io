Reproduce
=========

- With Nix_: run ``nix-build``
- Otherwise: Get `TeX Live`_, rubber_ and ninja_ then run ``ninja``.

.. _Nix: https://nixos.org/nix/
.. _TeX Live: https://www.tug.org/texlive/
.. _rubber: https://launchpad.net/rubber/
.. _ninja: https://ninja-build.org/
