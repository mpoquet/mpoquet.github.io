---
title: Introduction to the Nix Package Manager
author: Millian Poquet
theme: Estonia
date: 2021-05-12 — Datamove (Inria) seminar
lang: fr
classoption:
- aspectratio=43
header-includes:
- |
  ```{=latex}
  \usepackage{subcaption}
  \setbeamertemplate{footline}[frame number]
  \renewcommand\dots{\ifmmode\ldots\else\makebox[1em][c]{.\hfil.\hfil.}\thinspace\fi}
  \hypersetup{colorlinks,linkcolor=,urlcolor=estonian-blue}
  \graphicspath{{./fig/},{./img/}}

  % Fix pandoc shenanigans
  \setbeamertemplate{section page}{}
  \setbeamertemplate{subsection page}{}
  \AtBeginSection{}
  \AtBeginSubsection{}
  ```
---

# Introduction
### Why Nix?
**Control your software environment!**

- Programs/libraries/scripts/configurations + versions

\vspace{8mm}
Why is it important for us?

- Use/develop/test/distribute software
  - Manually install many dependencies? No, just type `nix-shell`
  - Shared env for whole team (tunable) and test machines
  - Bug only on my machine? Means this is hardware or OS related
- Reproducible research
  - Repeat experiment in exact same environment
  - Introduce or test variation

### What is Nix?
**Nix**: package manager

- Download and *install* packages
- Shell into well-defined environment (like `virtualenv`)
- Transactional (rollback works)
- Cross-platform: Linux, macOS, Windows (WSL)

\vspace{1mm}
**Nix**: programming language

- Define packages
- Define environments (set of packages)
- Functional, DSL

\vspace{1mm}
**NixOS**: Linux distribution

- Declarative system configuration
- Uses the Nix language
- Transactional (rollback still works)

### Nix in numbers

- Started in 2003
- Nix[^nix-github]: 10k commits, 28k C++ LOC
- Nixpkgs[^nixpkgs-github]: 285k commits, 55k packages[^nb-pkg-src]

\vspace{5mm}
\includegraphics[width=\textwidth]{nixpkgs-commits-screenshot.png}

[^nix-github]: `https://github.com/NixOS/nix`
[^nixpkgs-github]: `https://github.com/NixOS/nixpkgs`
[^nb-pkg-src]: `https://repology.org/repositories/statistics`

### Presentation summary

\tableofcontents[
  currentsection,
  sectionstyle=hide/show,
]

# Nix concepts
### Traditional package store (dpkg, rpm, pacman...)

\includegraphics[width=\textwidth]{pkgstruct-pacman.pdf}

- All packages merged together
- Name conflict $\rightarrow$ cannot store multiple versions \
  (or manual hack for each package)
- Use the *default* environment all the time
  - Bins in default dirs (`/bin/` or `/usr/bin/`) or hacked (debian)
  - Libs in default dirs (`/lib/` or `/usr/lib/`) or hacked (debian)
  - Vague file dependency (require `libmylib.so`)

### Nix store
\includegraphics[width=\textwidth]{pkgstruct-nix.pdf}

\vspace*{-2mm}
- All packages kept separated + links
- Store path: hash of inputs + package name
- Name conflicts?
  - Can *store* multiple versions
  - Cannot *enable* them simultaneously (in the same env)
- Precise dependency management
  - `DT_RUNPATH` set in ELFs (still hackable via `LD_LIBRARY_PATH`)
  - `PYTHONPATH`-like wrappers for interpreted scripts

### Package build workflow
\includegraphics[width=.95\textwidth]{package-datamove.pdf}

### Main ideas on building a Nix package
Build in a ~~jail~~ sandbox

- pure env variables
- no network access (src fetched by Nix, not by user code)
- no ipc
- isolated filesystem

\vspace{5mm}
Build phases

- unpack
- patch
- configure
- build
- check
- install

# Usage examples

### Nix package example: ``intervalset.nix``
```{=latex}
{\footnotesize
```

~~~~~~ {.nix .numberLines}
{ stdenv, fetchgit, meson, ninja, pkgconfig, boost, gtest }:

stdenv.mkDerivation rec {
  pname = "intervalset";
  version = "1.2.0";
  src = fetchgit {
    url = "https://gitlab.inria.fr/batsim/intervalset.git";
    rev = "v${version}";
    sha256 = "1ayj6jjznbd0kwacz6dki6yk4rxdssapmz4gd8qh1yq1z1qbjqgs";
  };
  buildInputs = [ meson ninja pkgconfig boost gtest ];
  # configurePhase = "meson build";
  # buildPhase = "meson compile -C build";
  # checkPhase = "meson test -C build";
  # installPhase = "meson install -C build";
}
~~~~~~

```{=latex}
}
```

### Package variation: ``override`` for inputs

```{=latex}
{\footnotesize
```

~~~~~ {.nix .numberLines}
packages = rec {
  intervalset = pkgs.callPackage ./intervalset.nix { };
  intervalset-as-debian = intervalset.override {
    boost = boost-167;
    meson = meson-049;
  };

  boost-176 = ...;
  boost-167 = ...;
  boost = boost-176;

  meson-058 = ...;
  meson-049 = ...;
  meson = meson-058;
};
~~~~~

```{=latex}
}
```

### Package variation: ``overrideAttrs`` for attributes

```{=latex}
{\footnotesize
```

~~~~~ {.nix .numberLines}
packages = rec {
  intervalset = pkgs.callPackage ./intervalset.nix { };
  intervalset-110 = intervalset.overrideAttrs (old: rec {
    version = "1.1.0";
    src = pkgs.fetchgit {
      url = "https://framagit.org/batsim/intervalset.git";
      rev = "v${version}";
      sha256 = "0kksrr1l9gv7fg6rdjz39ph9l6smy74jsahyaj6pmpi1kzs33qva";
    };
  });
  intervalset-local = intervalset.overrideAttrs (old: rec {
    version = "local";
    src = "/home/user/projects/intervalset";
    mesonBuildType = "debug";
  });
};
~~~~~

```{=latex}
}
```

### Define an environment: ``mkShell``

```{=latex}
{\scriptsize
```

~~~~~ {.nix .numberLines}
{ kapack ? import
(fetchTarball "https://github.com/oar-team/nur-kapack/archive/master.tar.gz"){}
}:
rec {
  pkgs = kapack.pkgs;
  expe-packages = [batsim-pinned batsched-pinned kapack.batexpe];
  expe-shell = pkgs.mkShell rec {
    name = "my-experiment-env";
    buildInputs = expe-packages;
  };
  expe-docker = pkgs.dockerTools.buildImage {
    name = "my-experiment-docker-env";
    tag = "latest";
    contents = expe-packages;
  };
  batsim-pinned = ...;
  batsched-pinned = ...;
  });
}
~~~~~

```{=latex}
}
```

### Command-line usage
\includegraphics[width=\textwidth]{screenshot-build-pkg.pdf}

```{=latex}
{\scriptsize
```

- ``nix-build -A <attr>`` builds ``derivation`` ``<attr>``
- ``nix-shell -A <attr>`` enters into the environment of attribute ``<attr>`` \
  (build env for ``derivation``, described env for ``mkShell``)
- ``nix-shell --command <cmd>`` runs ``<cmd>`` inside an environment

```{=latex}
}
```

# Conclusion
### Nix critique
Strengths

- No missing dependencies, local build likely works anywhere
- No boilerplate: Nix package = information needed to build it
- ``nix-shell`` = multi-language ``virtualenv``
- Minimal size docker container generation is trivial
- Distributed Nix expressions — *e.g.*, nur-kapack[^nur-kapack]

Weaknesses

- Contaminant: dependencies must be expressed in Nix
- Learning curve — entry-level doc[^nix-doc] improved a lot recently
- Implicit behaviors to build packages (looks magic at first sight)
- If used to dev: change in practice (for the greater good)
- Turing complete considered harmful — Guix/Spack do worse

[^nur-kapack]: ``https://github.com/oar-team/nur-kapack``
[^nix-doc]: ``https://nixos.org``

### Take home message

Nix in a nutshell

- Define pure packages (build in sandbox)
- Control and isolate your environments

Steep learning curve, but most likely worth it

- If you want to make sure your code runs in 5 years
- If you want to escape dependency hell

Additional resources

- Nix official website[^nix-official] — install, getting started...
- Tutorial on Nix for reproducible experiments[^tuto-nix-repro-expe]
- Nix pills[^nix-pills] — AKA how nix works

[^nix-official]: ``https://nixos.org``
[^tuto-nix-repro-expe]: ``https://nix-tutorial.gitlabpages.inria.fr/nix-tutorial``
[^nix-pills]: ``https://nixos.org/guides/nix-pills``
